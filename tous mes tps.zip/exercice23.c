#include<stdio.h>
#include<stdlib.h>
#include<time.h>
#define TEMP_MIN -200
#define TEMP_MAX 300
#define TAILLE 31
// On reprend la température

//Question1

int* init_temp()
{
 int * tab = malloc(sizeof(int)*TAILLE);
 
 int d;
 int i;
 for(i=0;i<TAILLE;i++)
 {
	 d = (rand())%(TEMP_MAX-TEMP_MIN+1) + TEMP_MIN;
	 tab[i] = d/10;
 }
 return tab;
}

void affichage(int t[], size_t len)
{
	int i;
	for(i=0;i<len;i++)
	{
		printf("%d ",t[i]);
	}

}

//Question 2
float moy_temp(int* t,int len)
{
	int i,som=0;
	for(i=0;i<len;i++)
	{
		som+=t[i];
	}
	return (float)som/len;
}

//Question 3
float temp_neg(int t[],int len)
{
	int nb_ng=0;
	int som = 0;
	int i;
	for(i=0;i<len;i++)
	{
		if(t[i]<0)
		{
		nb_ng +=1;
		som+=t[i];
		}
	}
	if(nb_ng == 0)
	{
		printf("Aucune temperature au-dessous de zero.");
		return 0;
	}
	else
	{
		return (float)som / nb_ng;
	}
}
int main()
{
	srand(time(NULL));
	int  *t = init_temp();
	affichage(t,TAILLE);
	
	free(t);
	return 0;
}
