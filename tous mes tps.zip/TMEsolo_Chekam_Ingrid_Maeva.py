#TME solo

#Exercice 1

def ecarts(L:List[int], m:int)->Tuple[int,int,int]:
    """pas de précondition, la liste peut être vide, et dans ce cas on renvoie (0,0,0)"""
    a:int=0 
    b:int=0
    c:int=0
    i:int #variable d'itération
    for i in L:
        if i<m-1:
            a=a+1
        elif i>=m-1 and i<=m+1:
            b=b+1
        else:
            c=c+1
    return (a,b,c)
#jeu de tests
assert ecarts([],5)==(0,0,0)
assert ecarts([1,5,-2],3)==(2,0,1)
assert ecarts([2,6,9],-1)==(0,0,3)
assert ecarts([-5,2,6],15)==(3,0,0)
assert ecarts([0,1,6],2)==(1,1,1)

#Exercice 2

def plus_court(L:List[str])->Tuple[str,int]:
    """précondition : len(L) > 0"""
    i_min:int = 0#indice de la chaine la plus courte
    ch_min : str = L[0] #chaine la pluis courte
    i:int  # variable d'itération
    for i in range(len(L)):
        if len(L[i]) < len(ch_min):#l'inégalité stricte garantit que l'on ne considère que la première chaine la plus petite rencontrée
            ch_min=L[i]
            i_min = i
    return (ch_min,i_min)

#jeu de tests
assert plus_court(['un','deux','un']) == ('un',0)
assert plus_court(['pomme','un'])==('un',1)
assert plus_court(['un','un'])==('un',0)

#Exercice 3

def multiples(m:int,n:int,p:int)->List[int]:
    """précondition : m > 0  and n>0 and p>0 """
    i:int=1
    nbre:int=n
    multi : List[int]=[] #Liste des multiples de n
    while i<=m:
        if nbre%n == 0:
            multi.append(nbre)
            i = i+1
        nbre=nbre+1
    return [val for val in multi if val%p == 0]

#jeu de tests
assert multiples(10,3,4)==[12,24]
assert multiples(12,1,6) == [6,12]
assert multiples(1,9,3)==[9]
assert multiples(5,5,143)==[]


#Exercice 4

def deuxieme_plus_grand(L:List[int])->int:
    """précondition : len(L) >0"""
    max1:int=L[0] #variable qui contiendra le plus grand élément de la liste
    max2:int=L[0] #variable qui contiendra le deuxième plus grand élément de la liste
    i1:int #variable d'itération
    i2:int
    for i1 in L:
        if i1>max1: 
            max1=i1
    for i2 in L:
        if i2!=max1:
            if i2>max2:
                max2=i2
    return max2

#jeu de tests       
assert deuxieme_plus_grand([1,2,5,3,1,4,6,9,2,1])== 6
assert deuxieme_plus_grand([-1,2,-6,0])==0
assert deuxieme_plus_grand([1,1,1,1])==1
assert deuxieme_plus_grand([0,1,1,1])==0

        
        
        
