import random
import math
#exercice_3.8

#Question 1
def lancer_de6()->int:
    """renvoie une valeur entiere aleatoire comprise entre 1 et 6"""
    x : float = random.random()
    return math.floor((x * 6) +1)


#Question_2
#jeu de tests
random.seed(11)
assert lancer_de6()== 3
assert lancer_de6() == 4
random.seed(42)
assert lancer_de6() == 4
assert lancer_de6() == 1
assert lancer_de6() == 2

#question 3
def moyenne_plusieurs_lancers(n : int) -> float:
    """ précondition : n>0
    """
    somme : int = 0
    i : int = 0
    
    while i<n:
        somme = somme + lancer_de6()
        i = i + 1
    return somme/n


random.seed(11)
assert moyenne_plusieurs_lancers(2) == 3.5
random.seed(42)
assert moyenne_plusieurs_lancers(3) == 7/3

#Question 4
def frequence_valeur (r:int, n:int) ->float:
    """précondition : r>=1 and r<=6
        précondition : n>=0
        """
    i : int = 0
    lancer : int
    nb_apparition : int = 0
    while i<n:
        lancer = lancer_de6()
        if(lancer == r):
            nb_apparition = nb_apparition + 1
        i = i+1
    return nb_apparition/n

assert frequence_valeur(1,1) == 0.0
#assert frequence_valeur(1,10) == 0.2
#assert frequence_valeur(1,100) == 0.13

#question subsidiaire: La generation des valeurs aleatoires ne suit pas une loi uniforme

#question 5
def lancer_deN(n: int) -> int:
    """précontion : n>0
    renvoie une valeur entiere aleatoire comprise entre 1 et n"""
    x : float = random.random()
    return math.floor((x * n) +1)

assert 1 <= lancer_deN(20) <=20
assert 1<= lancer_deN(8) <=8
assert lancer_deN(1) == 1



#Exercice 4.5
#Question 1
def nb_couples_intervalle(n : int, p:int) -> int :
    """précondition : n<=p
renvoie le nombre de  couples situés entre n et p
"""
    i :int  = n
    nbre : int = 0
    while i<=(p-1):
        nbre = nbre + p-i
        i = i+ 1

    return nbre

assert nb_couples_intervalle(0,0) == 0
assert nb_couples_intervalle(2,4) == 3
assert nb_couples_intervalle(-1,3) == 10
    

#question 2
def nb_couples_divise(n :int, p : int) ->int :
    """ précondition : n<=p"""
    j :int = n + 1
    i : int 
    nbre : int = 0
    while j<=p:
        i = n 
        while i<j:
            if i == 0:
                i = i+1
            elif j%i==0:
                nbre = nbre + 1
            i = i + 1
        j = j+1
    return nbre

assert nb_couples_divise(4,6) == 0
assert nb_couples_divise(2,6) == 3
assert nb_couples_divise(-1,1) == 2
assert nb_couples_divise(1,10) == 17
    
#question 3
def nb_couples_divise_trace(n :int, p : int) ->int :
    """ précondition : n<=p"""
    j :int = n + 1
    i : int 
    nbre : int = 0
    while j<=p:
        i = n 
        while i<j:
            if i == 0:
                i = i+1
            elif j%i==0:
                nbre = nbre + 1
                print("couple ( ", j,",",i,")")
                print(i, "divise"
            i = i + 1
        j = j+1
    return nbre



