#include<stdio.h>
int compte_mots(char * str)
{
	int res=0;
	int i=0,j=0;
	while(str[i]!='\0')
	{
	if(str[i]!=' ') 
	{
	
	printf("%d, %d\n",i,res);
	

		j=i;
		while((str[j]!='\0')&&(str[j]!=' '))
		{
			j=j+1;
		}
		res=res+1;
		i=j;
	}
	else {i=i+1;}
	}
	return res;
}
int main()
{
	char* x = " je ne nara  naar pas souvent ";
	//printf("Nombre de mots dans \"%s\" : %d\n", x, compte_mots(x));
	 printf("nombre de mots : %d\n",compte_mots("mot1 mot2 mot3"));



printf("nombre de mots : %d\n",compte_mots("mot1  mot2    mot3"));



printf("nombre de mots : %d\n",compte_mots("   mot1 mot2 mot3 mot4"));



printf("nombre de mots : %d\n",compte_mots("mot1 mot2 mot3 mot4 mot5  "));

printf("nombre de mots : %d\n",compte_mots("   mot1     mot3     "));

printf("nombre de mots : %d\n",compte_mots("mot1mot2mot3"));
	

printf("nombre de mots : %d\n",compte_mots("   mot1mot2mot3   "));

	

printf("nombre de mots : %d\n",compte_mots(""));


printf("nombre de mots : %d\n",compte_mots("    "));


printf("nombre de mots : %d\n",compte_mots("mot motpluslong  motcourt  motencorepluslong   "));
	return 0;
}
