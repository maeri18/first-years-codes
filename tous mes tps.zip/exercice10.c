#include<stdio.h>
#include<cini.h>

void carre(int l)
{
	int i;
	for(i=0;i<l;i++)
	{
		CINI_draw_pixel(i,0,"blue");
		CINI_draw_pixel(0,i,"red");
		CINI_draw_pixel(i,l,"green");
		CINI_draw_pixel(l,i,"black");
		
	}
	CINI_loop();
}
void carre1(int l, int x, int y)
{
	int i;
	for (i=0;i<l;i++)
	{
		CINI_draw_pixel(x+i,y,"blue");
		CINI_draw_pixel(x,y+i,"red");
		CINI_draw_pixel(x+i,y+l,"green");
		CINI_draw_pixel(x+l,y+i,"black");
	}
	//CINI_loop(); // NB: cette instruction a été enlevée juste pour que carre_remontant fonctionne sans avoir à cliquer tout le temps.
}	 

void carres_remontant(int l, int x, int y)
{
	int a=x, b=y;
	while(b>=0)
	{
	carre1(l,a,b);
	a-=20;
	b-=20;
	}
	CINI_loop();
}

int main()
{

	CINI_open_window(2000,2000,"Second");
	CINI_fill_window("white");
	//carre(500);
	//carre1(500,500,200);
	carres_remontant(200,500,200);
	return 0;
	
}
