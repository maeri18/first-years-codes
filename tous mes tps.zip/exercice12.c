#include<stdio.h>
#include<cini.h>

int position(int a, int b, int x, int y)
{
	int appartenance = a*x+b;
	if (appartenance > y)
	{ 
		return -1;
	}
	else if (appartenance < y)
	{ 
		return 1;
	}
	else 
	{
		return 0;
	}	
}

void affiche(int a, int b, int h, int l)
{
	int x, y,p;
	for(x=0; x<=h; x++)
	{
		for(y=0;y<=l;y++)
		{
			p = position(a,b,x,y);
			if(p==0)
			{
				CINI_draw_pixel(x,y,"black");
			}
			else if(p==1)
			{
				CINI_draw_pixel(x,y,"pink");
			}
			else
			{
				CINI_draw_pixel(x,y,"light green");
			}
		}
	}
	CINI_loop();
}

int main()
{
	CINI_open_window(2000,2000,"Third");
	CINI_fill_window("white");
	affiche(2,3,2000,2000);
	CINI_loop();
	return 0;
}
				

			
