#include<stdio.h>
#include<stdlib.h>
#include<assert.h>

int est_deb(char * str1, char* str2)
{
	if(str1[0]=='\0')
	{
		return 1;
	}
	else
	{
		if(str1[0]!=str2[0])
		{
			return 0;
		}
		else
		{
			return est_deb(str1+1,str2+1);
		}
	}		
}

int est_deb2(char * str1, char* str2)
{
	if(str1[0]=='\0')
	{
		return 1;
	}
	else
	{
		if(str1[0]!=str2[0])
		{
			return 0;
		}
		else
		{
			return est_deb(str1+1,str2+1);
		}
	}		
} 

int est_incluse(char * str1, char* str2)
{
	if(str2[0]=='\0')
	{
		return 0;
	}
	else
	{
		if(est_deb(str1,str2))
		{
			return 1;
		}
		else
		{
			return est_incluse(str1,str2+1);
		}
	}
	
}

int main()
{
	assert(est_deb("alpha","alphabet")==1);
 	assert(est_deb("beta","alphabet")==0);
 	assert(est_deb("bonjour","bon")==0);
 	assert(est_incluse("alpha","alphabet")==1);
 	assert(est_incluse("bet","alphabet")==1);
 	return 0;
}
