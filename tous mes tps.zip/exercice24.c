#include<stdio.h>
#include<stdlib.h>
#define TAILLE 10

int indiceInsert(int tab[], int nbEl, int el,int taille)
{
	int i;
	if(nbEl>=taille)
	{
	return -1;
	}
	for(i=0;i<nbEl;i++)
	{
		if (tab[i]>=el)
		{
			return i;
		}
	}
	return nbEl;
}

int insertElt (int el, int tab[],int nbEl, int taille)
{
	int id = indiceInsert(tab, nbEl, el,taille);
	if(id!=-1)
	{
		if (tab[id]!=el)
		{
			for(int i = nbEl; i>id;i--)
			{
				tab[i]=tab[i-1];
			}
			tab[id] = el;
			return 1;
		}
	}
	return 0;
}
void affiche_tab(int tab[], int len)
{
	for(int i=0;i<len;i++)
	printf("%d ",tab[i]);
}

int main()
{
	int tab[6]={1,8,56,96,100};
	int el = 0;
	int d=insertElt( el, tab, 5,6);
	if (d!=0)
	affiche_tab(tab,6);
	return 0;
}

