#Exercice 6.1
#Question 1
def repetition(x:T,k:int)->List[T]:
    """précondition :  k>=0
renvoie la liste contenant k occurences de x"""
    lres:List[T]=[] #liste qui contiendra les k occurences x
    i:int = 0
    while i!=k:
        lres.append(x)
        i=i+1
    return lres
#jeu de tests
assert repetition("thon",4) == ["thon","thon","thon","thon"]
assert repetition(3,8)==[3,3,3,3,3,3,3,3]
assert repetition("Mum",0)==[]
assert repetition("",3)==["","",""]

#question 2
def repetition_bloc(l:List[T],k:int)->List[T]:
    """précondition : k>=0
renvoie la liste obtenue en concatenant k fois la liste l"""
    lres:List[T]=[]#liste résultante 
    i:int#variable d'itération
    for i in range(k):
        lres = lres + l
    return lres
#jeu de tests
assert repetition_bloc(["chat","tonic","rouge"],3)==["chat","tonic","rouge","chat","tonic","rouge","chat","tonic","rouge"]
assert repetition_bloc([],4) == []
assert repetition_bloc([2,56,3,2,5],0)==[]
assert repetition_bloc([],0)==[]

#exercice 6.2
#Question 1
def max_liste(l:List[float])->float:
    """précondition: l!=[]
renvoie le maximum de la liste l"""
    
    x:float#variable d'itération
    max:float=l[0]#variable qui contiendra la maximum de l
    for x in l:
        if x>max:
            max=x
    return max
#jeu de tests
assert max_liste([3,7,9,5.4,8.9,9,8.999,5])== 9
assert max_liste([8,0,-6,4])==8
assert max_liste([2,-2,6,9,55,22,1.4])==55
#Question 2
def nb_occurences(L:List[T],x:T)->int:
    """renvoie le nombre d'occurences de x dans L"""
    x1 : T#variable d'iteration qui va parcourir la liste L
    nbre_occ:int=0#variable qui va contenir le nombre d'occurences de x dans L
    for x1 in L:
        if x1==x:
            nbre_occ= nbre_occ+1
    return nbre_occ
assert nb_occurences([3,7,9,5.4,8.9,9,8.99,5],9)==2
assert nb_occurences(["chat","ours","chat","chat","loup"],"chat")==3
assert nb_occurences(["chat","tonic","rouge","coco"],"vert")==0
assert nb_occurences([],2)==0

#Question 3
def nb_max(L:List[float])->int:
    """précondition : L!=[]
renvoie le nombre d'occurences du """
    return nb_occurences(L,max_liste(L))
#Jeu de tests
assert nb_max([3,7,9,5.4,8.9,9,8.999,5])==2
assert nb_max([-2, -1, -5, -3, -1, -4, -1]) == 3
assert nb_max([2,5,1.6,-8,5,0,5,5])==4


#Exercice 6.7
#Question 1
def liste_mult(L:List[int],k:int)->List[int]:
    """renvoie la ,liste obtenue en multipliant tous les éléments de L par k"""
    lres:List[int]=[]#variable qui contiendra la liste résultante 
    i:int#variable d'itération
    for i in L:
        lres.append(i*k)
    return lres
#Jeu de tests
assert liste_mult([],5) == []
assert liste_mult([3, 5, 9, 4], 2)== [6, 10, 18, 8]

#Question 2
def liste_div(L:List[int],k:int)->List[int]:
    """précondition : k!=0
renvoie la liste obtenue en divisant les éléments de L qui sont multiples de k par k et en supprimant les autres"""
    lres:List[int]=[]#variable qui contiendra la liste résultante 
    i:int#variable d'itération
    for i in L :
        if i%k==0:
            lres.append(i//k)
    return lres
#Jeu de tests
assert liste_div([2, 7, 9, 24, 6], 2)==[1, 12, 3]
assert liste_div([], 2)==[]
assert liste_div([2, 7, 25, 8,11 ], 3)==[]
assert liste_div([2, 7, 9, -24, 6], -3) == [-3, 8, -2]


 

