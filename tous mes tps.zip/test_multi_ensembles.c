#include <stdio.h>
#include "multi_ensembles.h"

int main() {
	element_t* L = NULL;
	for(int i = 0; i<5;i++)
	{
		L = add_elem(L,i,1);
	}
	
	L = Ajout_tete_ensemble(L, 0, 2);
	L = Ajout_tete_ensemble(L, 5, 2);
	//L = Ajout_tete_ensemble(L, 8, 2);
	Affiche_ensemble(L);
	printf("\n\n");
	//L = Supprime_total_element_ensemble(L, 6);
	//L =  Supprime_element_ensemble_trie(L, 0);
	//L =  Supprime_total_element_ensemble_trie(L, 0);
	 //L = Ajout_ensemble_trie(L, 6, 2);
	//Affiche_ensemble(L);
	
	L =  Supprime_frequence_inf_seuil(L, 1);
	Affiche_ensemble(L);
	
  return 0;
}

 
