#include<stdio.h>
#include<stdlib.h>
#include<time.h>
#define MAX 15
#define MIN 2


int * init_alea()
{
	int taille = rand()%(MAX-MIN+1)+MIN;
	int *t=malloc((taille+1)*sizeof(int));
	if(t==NULL) 
	{
		exit(1);
	}
	for(int i=0;i<taille;i++)
	{
		t[i]=rand()%2;
	}
	t[taille]=-1;
	return t;		
}
int compress_tab(int tab_brut[],int tab_compress[])
{
	int i=0,j=0;
	int cmpt=0;
	int nb=0;
	while(tab_brut[i]!=-1)
	{
		cmpt=i;
		while(tab_brut[cmpt]==tab_brut[i])
		{
			nb++;
			cmpt++;
		}
		if(nb==1)
		{
			tab_compress[j]=tab_brut[i];
		}
		else
		{
			tab_compress[j]=nb;
			tab_compress[j+1]=tab_brut[i];
			j++;
		}
		j++;
		nb=0;
		i=cmpt;
	}
	tab_compress[j]=-1;
	return j;
}

int decompress_tab(int tab_brut[],int tab_compress[])
{
	int i=0,j=0;
	int nb=0;
	
	while(tab_compress[i]!=-1)
	{
		if(tab_compress[i]==0 || tab_compress[i]==1)
		{
			tab_brut[j]=tab_compress[i];
			j++;
			i++;
		}
		else
		{
			nb = tab_compress[i];
			for(int i1=0;i1<nb;i1++)
			{
				tab_brut[j]=tab_compress[i+1];
				j++;
			}
			i=i+2;	
		}
	}
	tab_brut[j]=-1;
	return j;
}
int compare(int tab1[],int tab2[])
{
	int i=0;
	
	while((tab1[i]!=-1)||(tab2[i]!=-1))
	{
		if(tab1[i]!=tab2[i])
		{
			return 0;
		}
		i++;
	}
	if(((tab1[i]==-1) && (tab2[i]!=-1))||((tab1[i]==-1) && (tab2[i]!=-1)))
	{
		return 0;
	}
	return 1;
}
void affiche(int tab[])
{
	int i=0;
	while(tab[i]!=-1)
	{
		printf("%d ",tab[i]);
		i++;
	}
	printf("%d \n",tab[i]);
}
int main()
{

int tab[18] = {0,0,1,1,1,1,0,1,1,1,0,0,1,0,0,0,0,-1};
int tabres[18] ;
int d =compress_tab(tab,tabres);
affiche(tabres);
int tabderes[18];
d = decompress_tab(tabderes,tabres);
affiche(tabderes);
printf("%d \n",compare(tab,tabderes));
free(tabres);
free(tabderes);
	return 0;
}

