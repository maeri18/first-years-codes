#include<stdio.h>
#include<stdlib.h>
#include <cini.h>

#define N       4
#define COEFX  50    /* coefficients d'echelle */
#define COEFY  38
#define DX    250    /* position dans la fenetre */
#define DY    420

void calcule_bornes_sup(int tab[],size_t len)
{
//precondition:La somme des elements de tab doit donner 100
	int d;
	if(len>0)
	{
		d=tab[0]-1;
		for(int i=0;i<len-1;i++)
		{
			tab[i]=d;
			d=d+tab[i+1];
		}
		tab[len-1]=tab[len-2]+tab[len-1];
	}
}

int tire_non_equi(int tab[],size_t len)
{
//precondition : Les elements de tab sont des entiers naturels croissants dont le dernier (qui est aussi le plus grand) est 99
	int val = rand()%100;
	int i=0;
	while((tab[i]<val)&&(i<len))
	{
		i++;
	}
	if(i<len)
	{
		return i;
	}
	return -1; //si la precondition n'est pas respectee, il se peut que i==len. par exemple si le dernier element est inferieur a 99, et qu'on tire un nombre superieur a 99.
}

void affiche_tab(int tab[], size_t len)
{
	for(int i=0;i<len;i++)
	{
		printf("%d ",tab[i]);
		
	}
	printf("\n");
}

int main()
{
	int tab[4]={17,28,50,5};
	int res[4]={0,0,0,0};
	calcule_bornes_sup(tab,4);
	int i,result;
	for(i=0;i<10000;i++)
	{
		result=tire_non_equi(tab,4);
		res[result]=res[result]+1;
	}
	affiche_tab(res,4);
   float tab_A[N] = {0.5,  0.2, -0.15,  0.85};    /* les coefficients a_i */
   float tab_B[N] = {0,   -0.26, 0.28,  0.04};    /* les coefficients b_i */
   float tab_C[N] = {0,    0.23, 0.26, -0.04};    /* les coefficients c_i */
   float tab_D[N] = {0.16, 0.22, 0.24,  0.85};    /* les coefficients d_i */
   float tab_E[N] = {0,    0,    0,     0};       /* les coefficients e_i */
   float tab_F[N] = {0,    1.6,  0.44,  1.6};     /* les coefficients f_i */
   
   int tab_P[N] = {1, 7, 7, 85};  /* pourcentages de chaque transformation */
   
   char *couleurs[N] = {"lime green", "fuchsia", "yellow", "turquoise"};

   /* Definition de variables supplementaires si necessaire */
  int choix;
  float x=0, y=0;

   /* Calcul des bornes des intervalles */
    calcule_bornes_sup(tab_P,N);
         
   
   CINI_open_window(500, 500, "feuille");
   
   do {
	
      /* Choix du numero de la transformation a appliquer */
   
            choix = tire_non_equi(tab_P, N);
      
      /* Calcul du point a tracer (coordonnees x et y) */
      x = tab_A[choix]*x + tab_B[choix]*y + tab_E[choix];
      y = tab_C[choix]*x + tab_D[choix]*y + tab_F[choix];
   
            /* A COMPLETER */
                  
      CINI_draw_pixel(DX + x*COEFX, DY - y*COEFY, couleurs[choix]);      
      
   } while (! CINI_key_down());

	return 0;
}

