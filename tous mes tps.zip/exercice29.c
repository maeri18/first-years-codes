#include<stdio.h>
#include<string.h>
#include<stdlib.h>
void affiche_lettres(char * str)
{
	int i=-1;
	while(str[++i])
	{
		if((str[i]== 'a' ) || (str[i]== 'e') || (str[i]== 'i' ) || (str[i]== 'o' ) || (str[i]== 'u' ) || (str[i]== 'A')  || (str[i]== 'E')  || (str[i]== 'I') || (str[i]== 'O') || (str[i]== 'U')) 
		{
			printf("%c",str[i]);
		}
	}
	printf("\n");
}

char* just_letters(char * str)
{
	int i=-1, l=strlen(str),j=0;
	char * res=malloc(l*sizeof(char));
	if(res==NULL) {exit(1);}
	while(str[++i])
	{
		if((str[i]== 'a' ) || (str[i]== 'e') || (str[i]== 'i' ) || (str[i]== 'o' ) || (str[i]== 'u' ) || (str[i]== 'A')  || (str[i]== 'E')  || (str[i]== 'I') || (str[i]== 'O') || (str[i]== 'U')) 
		{
			res[j]=str[i];
			j=j+1;
		}
	}
	res[j]='\0';
	return res;
}
/*
void modif(char** str)
{
 *str="plus";
}
*/
void filtrage_en_place(char *str)
{
	int i=0;
	int j=0;
	while(str[i]!='\0')
	{
		if((str[i]== 'a' ) || (str[i]== 'e') || (str[i]== 'i' ) || (str[i]== 'o' ) || (str[i]== 'u' ) || (str[i]== 'A')  || (str[i]== 'E')  || (str[i]== 'I') || (str[i]== 'O') || (str[i]== 'U'))
		{
			str[j]=str[i];
			j=j+1;
		}
		i=i+1;
	}
	str[j]='\0';
}
int main()
{
/*
char * str="opop" ;
modif(&str);
//printf("%s\n",str);*/
char essay[50] = {'I','o','u',' ','m','o','u',' ','k','i','m','i',' ','w','o',' ','d','a','r','e',' ','k','a',' ','s','h','u',' ','u',' ','n','i',' ','n','i','g','e','t','a','\0'};
filtrage_en_place(essay);
printf("%s\n",essay);
// donc oui, c'est possible de modifier directement une chaine, si elle est a ete declree forme de tableau. Ainsi, meme si dans l'appel a la fonction on utilise la forme pointeur, la chaine sera toujours modifiee 
//printf("Letters: %s\n", just_letters("Neriyah et lemy mangent avec videline")); 
return 0;
}
