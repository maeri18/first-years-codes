#include<stdio.h>
//Question 1

int rech_it_non_trie(int tab[], int len,int elem)
{
	for(int i=0;i<len;i++)
	{
		if(tab[i]==elem)
		{
			return 1;
		}
	}
	return 0;
}


//Question 2 cas d'arrêt : tableau vide(len =0) 

//Question 3

int rech_rec_non_trie(int tab[], int len,int elem)
{
	if(len==0)
	{
		return 0;
	}
	else
	{
		if (tab[0]==elem)
		{
			return 1;
		}
		return rech_rec_non_trie(tab+1,len-1,elem);
	}
}

//Question 4 : si le tableau est déjà trié (dans l'ordre croissant), on va procéder à une recherche dichotomique

// Cas itératif
int rech_it_dich ( int tab[], int len , int elem )
{
	int a = 0;
	int b = len - 1;
	int m;
	int i = 0;
	if (len !=0)
	{
		while(a<=b)
		{
			m = ( a + b ) / 2;
			if( tab[m] == elem )
			{
				return 1;
			}
			else if( tab[m] < elem )
			{
				a = m + 1;	
			}
			else
			{
				b = m - 1;
			}
		}
	}
	return 0;
}


// Cas récursif
int rech_rec_dich ( int tab[],int a,int b,int elem)
{
	int m =  ( a + b ) / 2;
	if(b<a)
	{
		return 0;
	}
	else if ( tab[m] == elem )
	{
		return 1;
	}
	else
	{
		if ( tab[m] < elem )
		{
			return rech_rec_dich(tab,m+1,b,elem);
		}
		else
		{
			return rech_rec_dich(tab,a,m-1,elem); 
		}	
	}
}
void affiche_tab(int tab[], int len)
{
	if(len==0)
	{
		printf("Tableau vide\n");
	}
	else
	{
		for(int i=0;i<len;i++)
		{
			printf("%d ",tab[i]);
				
		}
		printf("\n");
	}
}
int main()
{
	int tab1[0];
	int tab2[1]={4};
	int tab3[6]={1,2,6,15,26,35};
	int tab4[9]={1,2,4,6,10,15,17,26,35};
	int tab5[9]={2,1,4,10,15,26,17,35,6};
	
	int val1 = 0;
	int val2 = 4;
	int val3 = 2;
	int val4 = 15;
	int val5 = 10;
	int val6 = 18;
	int val7 = 26;
	int val8 = 55;
	
	printf("*********************Tests rech_it_non_trie***********************\n");
	printf("Tableau : ");
	affiche_tab(tab1,0);
	printf("recherche de %d dans le tableau : ...\nresultat de la recherche : %d\n\n",val4,rech_it_non_trie(tab1,0,val4));
	
	printf("Tableau : ");
	affiche_tab(tab2,1);
	printf("recherche de %d dans le tableau : ...\nresultat de la recherche : %d\n\n",val2, rech_it_non_trie(tab2,1,val2));
	
	printf("Tableau : ");
	affiche_tab(tab5,9);
	printf("recherche de %d dans le tableau : ...\nresultat de la recherche : %d\n\n",val6,rech_it_non_trie(tab5,9,val6));
	
	printf("*********************Tests rech_rec_non_trie***********************\n");
	printf("Tableau : ");
	affiche_tab(tab1,0);
	printf("recherche de %d dans le tableau : ...\nresultat de la recherche : %d\n\n",val4,rech_rec_non_trie(tab1,0,val4));
	
	printf("Tableau : ");
	affiche_tab(tab2,1);
	printf("recherche de %d dans le tableau : ...\nresultat de la recherche : %d\n\n",val2, rech_rec_non_trie(tab2,1,val2));
	
	printf("Tableau : ");
	affiche_tab(tab5,9);
	printf("recherche de %d dans le tableau : ...\nresultat de la recherche : %d\n\n",val6,rech_rec_non_trie(tab5,9,val6));
	
	
	printf("*********************Tests rech_it_dich***********************\n");
	printf("Tableau : ");
	affiche_tab(tab1,0);
	printf("recherche de %d dans le tableau : ...\nresultat de la recherche : %d\n\n",val1, rech_it_dich(tab1,0,val1));
	
	printf("Tableau : ");
	affiche_tab(tab2,1);
	printf("recherche de %d dans le tableau : ...\nresultat de la recherche : %d\n\n",val2, rech_it_dich(tab2,1,val2));
	
	printf("Tableau : ");
	affiche_tab(tab2,1);
	printf("recherche de %d dans le tableau : ...\nresultat de la recherche : %d\n\n",val3,rech_it_dich( tab2,1,val3));
	
	printf("Tableau : ");
	affiche_tab(tab3,6);
	printf("recherche de %d dans le tableau : ...\nresultat de la recherche : %d\n\n",val2 , rech_it_dich( tab3,6,val2));
	
	printf("Tableau : ");
	affiche_tab(tab3,6);
	printf("recherche de %d dans le tableau : ...\nresultat de la recherche : %d\n\n",val3, rech_it_dich( tab3,6,val3));
	
	printf("Tableau : ");
	affiche_tab(tab3,6);
	printf("recherche de %d dans le tableau : ...\nresultat de la recherche : %d\n\n",val4, rech_it_dich( tab3,6,val4));
	
	printf("Tableau : ");
	affiche_tab(tab3,6);
	printf("recherche de %d dans le tableau : ...\nresultat de la recherche : %d\n\n",val5, rech_it_dich( tab3,6,val5));
	
	printf("Tableau : ");
	affiche_tab(tab3,6);
	printf("recherche de %d dans le tableau : ...\nresultat de la recherche : %d\n\n",val6, rech_it_dich( tab3,6,val6));
	
	printf("Tableau : ");
	affiche_tab(tab3,6);
	printf("recherche de %d dans le tableau : ...\nresultat de la recherche : %d\n\n",val7, rech_it_dich( tab3,6,val7));
	
	printf("Tableau : ");
	affiche_tab(tab3,6);
	printf("recherche de %d dans le tableau : ...\nresultat de la recherche : %d\n\n",val8, rech_it_dich( tab3,6,val8));
	
	printf("Tableau : ");
	affiche_tab(tab4,6);
	printf("recherche de %d dans le tableau : ...\nresultat de la recherche : %d\n\n",val2 , rech_it_dich( tab4,6,val2));
	
	printf("Tableau : ");
	affiche_tab(tab4,6);
	printf("recherche de %d dans le tableau : ...\nresultat de la recherche : %d\n\n",val3, rech_it_dich( tab4,6,val3));
	
	printf("Tableau : ");
	affiche_tab(tab4,6);
	printf("recherche de %d dans le tableau : ...\nresultat de la recherche : %d\n\n",val4, rech_it_dich( tab4,6,val4));
	
	printf("Tableau : ");
	affiche_tab(tab4,6);
	printf("recherche de %d dans le tableau : ...\nresultat de la recherche : %d\n\n",val5, rech_it_dich( tab4,6,val5));
	
	printf("Tableau : ");
	affiche_tab(tab4,6);
	printf("recherche de %d dans le tableau : ...\nresultat de la recherche : %d\n\n",val6, rech_it_dich( tab4,6,val6));
	
	printf("Tableau : ");
	affiche_tab(tab4,6);
	printf("recherche de %d dans le tableau : ...\nresultat de la recherche : %d\n\n",val7, rech_it_dich( tab4,6,val7));
	
	printf("Tableau : ");
	affiche_tab(tab4,6);
	printf("recherche de %d dans le tableau : ...\nresultat de la recherche : %d\n\n",val8, rech_it_dich(tab4,6,val8));
	
	
	printf("*********************Tests rech_rec_dich***********************\n");
	printf("Tableau : ");
	affiche_tab(tab1,0);
	printf("recherche de %d dans le tableau : ...\nresultat de la recherche : %d\n\n",val1, rech_rec_dich(tab1,0,0,val1));
	
	printf("Tableau : ");
	affiche_tab(tab2,1);
	printf("recherche de %d dans le tableau : ...\nresultat de la recherche : %d\n\n",val2, rech_rec_dich(tab2,0,1,val2));
	
	printf("Tableau : ");
	affiche_tab(tab2,1);
	printf("recherche de %d dans le tableau : ...\nresultat de la recherche : %d\n\n",val3,rech_rec_dich( tab2,0,1,val3));
	
	printf("Tableau : ");
	affiche_tab(tab3,6);
	printf("recherche de %d dans le tableau : ...\nresultat de la recherche : %d\n\n",val2 , rech_rec_dich( tab3,0,6,val2));
	
	printf("Tableau : ");
	affiche_tab(tab3,6);
	printf("recherche de %d dans le tableau : ...\nresultat de la recherche : %d\n\n",val3, rech_rec_dich( tab3,0,6,val3));
	
	printf("Tableau : ");
	affiche_tab(tab3,6);
	printf("recherche de %d dans le tableau : ...\nresultat de la recherche : %d\n\n",val4, rech_rec_dich( tab3,0,6,val4));
	
	printf("Tableau : ");
	affiche_tab(tab3,6);
	printf("recherche de %d dans le tableau : ...\nresultat de la recherche : %d\n\n",val5, rech_rec_dich( tab3,0,6,val5));
	
	printf("Tableau : ");
	affiche_tab(tab3,6);
	printf("recherche de %d dans le tableau : ...\nresultat de la recherche : %d\n\n",val6, rech_rec_dich( tab3,0,6,val6));
	
	printf("Tableau : ");
	affiche_tab(tab3,6);
	printf("recherche de %d dans le tableau : ...\nresultat de la recherche : %d\n\n",val7, rech_rec_dich( tab3,0,6,val7));
	
	printf("Tableau : ");
	affiche_tab(tab3,6);
	printf("recherche de %d dans le tableau : ...\nresultat de la recherche : %d\n\n",val8, rech_rec_dich( tab3,0,6,val8));
	
	printf("Tableau : ");
	affiche_tab(tab4,6);
	printf("recherche de %d dans le tableau : ...\nresultat de la recherche : %d\n\n",val2 , rech_rec_dich( tab4,0,6,val2));
	
	printf("Tableau : ");
	affiche_tab(tab4,6);
	printf("recherche de %d dans le tableau : ...\nresultat de la recherche : %d\n\n",val3, rech_rec_dich( tab4,0,6,val3));
	
	printf("Tableau : ");
	affiche_tab(tab4,6);
	printf("recherche de %d dans le tableau : ...\nresultat de la recherche : %d\n\n",val4, rech_rec_dich( tab4,0,6,val4));
	
	printf("Tableau : ");
	affiche_tab(tab4,6);
	printf("recherche de %d dans le tableau : ...\nresultat de la recherche : %d\n\n",val5, rech_rec_dich( tab4,0,6,val5));
	
	printf("Tableau : ");
	affiche_tab(tab4,6);
	printf("recherche de %d dans le tableau : ...\nresultat de la recherche : %d\n\n",val6, rech_rec_dich( tab4,0,6,val6));
	
	printf("Tableau : ");
	affiche_tab(tab4,6);
	printf("recherche de %d dans le tableau : ...\nresultat de la recherche : %d\n\n",val7, rech_rec_dich( tab4,0,6,val7));
	
	printf("Tableau : ");
	affiche_tab(tab4,6);
	printf("recherche de %d dans le tableau : ...\nresultat de la recherche : %d\n\n",val8, rech_rec_dich(tab4,0,6,val8));
	
	return 0;	
}

