
#include "multi_ensembles.h"
element_t* add_elem(element_t* L, int val, int freq)
{
	element_t* tmp =L;
	element_t* new = malloc(sizeof(element_t));
	if(!new)
	 		{
	 			return NULL;
	 		}
	 new->valeur = val;
	 new->frequence =  freq;
	 new->suivant = NULL;
	 if(!L)
	 {
	 	return new;
	 }
	 else
	 {
	 	while(tmp->suivant)
		{
			tmp = tmp->suivant;
		}
		 
		tmp->suivant = new;		
		return L;
	 }
	
}
  
/* Retourne un pointeur sur le premier element de valeur val, retourne NULL si aucun �l�ment n'a la valeur val */
element_t * Recherche_val(element_t *ensemble, int val) 
{
	if(ensemble == NULL)
	{
		return NULL;
	}
	else if(ensemble->valeur == val)
	{
		return ensemble;
	}
	else
	{
		return Recherche_val(ensemble->suivant,val);
	}
}

/* Ajoute l'element val en tete de l'ensemble s'il n'apparait pas dans l'ensemble, augmente sa frequence de 1 sinon */
element_t * Ajout_tete_ensemble(element_t *ensemble, int val, int freq) 
{
 	element_t * in_it = Recherche_val(ensemble, val);
 	if(!in_it)
 	{
 		element_t * tmp = ensemble;
 		if(ensemble)
 		{
	 		
	 		while(tmp->suivant)
	 		{
	 			tmp = tmp->suivant;
	 		}
	 		tmp -> suivant = malloc(sizeof(element_t));
	 		if(!tmp->suivant)
	 		{
	 			return NULL;
	 		}
	 		tmp->suivant->valeur = val;
	 		tmp->suivant->frequence =  freq;
 		}
 		else
 		{
 			tmp = malloc(sizeof(element_t));
 			tmp->valeur = val;
	 		tmp->frequence =  freq;
	 		return tmp;
 		}
 				
 	}
 	else
 	{
 		in_it->frequence = in_it->frequence + freq;
 	}
 	return ensemble;
}

element_t * Ajout_tete_ensemble_(element_t *ensemble, int val, int freq) 
{
 	element_t * in_it = Recherche_val(ensemble, val);
 	if(!in_it)
 	{
 		element_t * tmp =  malloc(sizeof(element_t));
 		tmp->valeur = val;
	 	tmp->frequence =  freq;
	 	tmp->suivant = ensemble;
	 	return tmp;			
 	}
 	else
 	{
 		in_it->frequence = in_it->frequence + freq;
 	}
 	return ensemble;
}
/* Supprime l' �l�ment de valeur val d'un ensemble*/
element_t* Supprime_total_element_ensemble(element_t* ensemble, int val)
{
	element_t* tmp = ensemble;
	element_t * prec = NULL;
	if(!ensemble)
	{
		return NULL;
	}
	else
	{
		while(tmp)
		{
			if(prec == NULL && tmp->valeur == val)
			{
				element_t * tmp2 = tmp;
				tmp = tmp ->suivant;
				free(tmp2);
				return tmp;
			}
			else
			{
				if(tmp->valeur == val)
				{
					prec->suivant = tmp->suivant;
					free(tmp);
					tmp = prec->suivant;
				}
				else
				{
					prec = tmp;
					tmp = tmp->suivant;
				}
			}
		}
	}
	return ensemble;
	
}
element_t* Supprime_element_ensemble(element_t* ensemble, int val)
{
	element_t* tmp = ensemble;
	element_t * prec = NULL;
	if(!ensemble)
	{
		return NULL;
	}
	else
	{
		while(tmp)
		{
			if(prec == NULL && tmp->valeur == val)
			{
				if(tmp->frequence <= 1)
				{
					element_t * tmp2 = tmp;
					tmp = tmp ->suivant;
					free(tmp2);
					return tmp;
				}
				else
				{
					tmp->frequence = tmp->frequence -1;
					prec = tmp;
					tmp = tmp->suivant;
					
				}
			}
			else
			{
				if(tmp->valeur == val)
				{
					if((tmp->frequence ) > 1)
					{
						tmp->frequence = tmp->frequence -1;
						prec = tmp;
						tmp = tmp->suivant;
					}
					else
					{
						prec->suivant = tmp->suivant;
						free(tmp);
						tmp = prec->suivant;
					}
					
				}
				else
				{
					prec = tmp;
					tmp = tmp->suivant;
				}
			}
		}
	}
	return ensemble;
}

element_t* Ajout_ensemble_trie(element_t* ensemble, int val, int freq)
{
	element_t* tmp = ensemble;
	element_t* prec = ensemble;
	element_t* new_el = malloc(sizeof(element_t));
	if(!new_el)
	{
		return NULL;
	}
	new_el->suivant = NULL;
	new_el->valeur = val;
	new_el->frequence = freq;
	
	if(!ensemble)
	{
		return new_el;
	}
	else
	{
		while(tmp)
		{
			if(tmp->valeur == val)
			{
				tmp->frequence = tmp->frequence + freq;
				break;
			}	
			else if(tmp->valeur > val)
			{
				if(tmp==prec)
				{
					new_el ->suivant = tmp;
					return new_el;
				}
				else
				{
					prec->suivant = new_el;
					new_el->suivant = tmp;
					prec = new_el;
				}
			}
			prec = tmp;
			tmp = tmp->suivant;
		}
		return ensemble;
	}
}
/*
element_t* Supprime_total_element_ensemble_rec(element_t* ensemble, int val)
{
	if(ensemble == NULL ) ()
	{
		return NULL;
	}
	else if (ensemble->valeur == val)
	{
		e
		return ensemble->suivant;
	}
	else if(ensemble->suivant->valeur == val)
	{	
		element_t * tmp = ensemble ->suivant;
		ensemble->suivant = ensemble ->suivant->suivant;
		free(tmp);
	}
	ensemble->suivant = Supprime_total_element_ensemble_rec(ensemble->suivant, val);
	return ensemble;
}*/

element_t* Supprime_element_ensemble_trie(element_t* ensemble, int val)
{
	element_t * tmp = ensemble;
	element_t* prec = ensemble;
	if(!ensemble)
	{
		return NULL;
	}
	else
	{
		while(tmp)
		{
			if(tmp->valeur == val)
			{
				if(tmp==prec)
				{
					if(tmp->frequence <= 1)
					{
						tmp = tmp->suivant;
						free(prec);
						prec = tmp;
					}
					else
					{
						tmp->frequence =  tmp->frequence - 1;
					}
				}
				else
				{
					if(tmp->frequence <= 1)
					{
						prec->suivant = tmp->suivant;
						free(tmp);
						tmp = prec->suivant;
					}
					else
					{
						tmp->frequence = tmp->frequence - 1;
					}
					
				}
				break;
			}
			else
			{
				prec = tmp;
				tmp = tmp->suivant;
			}
		}
	}
	return ensemble;
}

element_t* Supprime_total_element_ensemble_trie(element_t* ensemble, int val)
{
	element_t * tmp = ensemble;
	element_t * prec = ensemble;
	if(!ensemble)
	{
		return NULL;
	}
	else
	{
		while(tmp)
		{
			if(tmp->valeur == val)
			{
				if(tmp==prec)
				{
					
					tmp = tmp->suivant;
					free(prec);
					prec = tmp;
					ensemble = tmp;
						
				}
				else
				{
					prec->suivant = tmp->suivant;
					free(tmp);
					tmp = prec->suivant;
					
				}
				break;
			}
			else
			{
				prec = tmp;
				tmp = tmp->suivant;
			}
		}
	}
	return ensemble;
}
/* Affiche tous les elements d'un ensemble avec leur frequence */
void Affiche_ensemble(element_t *ensemble) {
  element_t *ptr = ensemble;
  if(ptr==NULL)
  {
  	printf("Liste vide\n\n");
  }
  while (ptr != NULL) {
    printf("val : %d, frequence : %d\n",ptr->valeur,ptr->frequence);
    ptr=ptr->suivant;
  }
}

/* Saisie des n elements d'un ensemble */
element_t * Creation_ensemble(int n) {
  element_t *ensemble=NULL;
  
  int i = 0;
  int val;
  
  for (i=0; i < n; i++) {
    printf("Saisie d'un entier: ");
    scanf("%d",&val);
    ensemble=Ajout_tete_ensemble(ensemble,val,1);
  }
  return ensemble;
}
