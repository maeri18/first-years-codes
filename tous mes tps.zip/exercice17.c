#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#define NB_VALEURS 50
#define VMIN -20
#define VMAX 20

int valeur_aleatoire(int min, int max)
{//pr�condition : min <=max
  
  int r = rand();
  float res = (r*(max))/RAND_MAX + min
  return (r*(max))/RAND_MAX ;
}

int main(){
  
  /* initialisation du g�n�rateur de nombres al�atoires */
  srand(time(NULL));
  int i ;
  for(i=0;i<NB_VALEURS;i++)
  {
  printf("%d \n", valeur_aleatoire(5,9));
  }
  return 0;
}
