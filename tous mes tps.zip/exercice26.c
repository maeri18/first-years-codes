#include<stdio.h>
#include<stdlib.h>

int* sort_fus(int tab1[],size_t taille1,int tab2[],size_t taille2)
{
	//précondition : tab1 et tab2 doivent être triés
	int i1=0,i2=0,ires=0;
	int * res = malloc(sizeof(int)*(taille2+taille1));
	
	if(res == NULL)
	{
		exit(1);
	}
	
	while(i1<taille1 && i2<taille2)
	{
		if(tab1[i1]<=tab2[i2])
		{
			res[ires] = tab1[i1];
			i1++;
		}
		else
		{
			res[ires] = tab2[i2];
			i2++;
		}
		ires++;
	}
	printf("i1 = %d , i2 = %d\n", i1,i2);
	if(i1<=taille1-1)
	{
		for(int i = i1;i<taille1;i++)
		{
			res[ires] = tab1[i];
			ires++;
		}
	}
	else if(i2<=taille2-1)
	{
		for(int i = i2; i<taille2;i++)
		{
			res[ires] = tab2[i];
			ires++;
		}
	}
	return res;
}

int main()
{
 int ta1[8] = {1,3,5,7,8,9,15,21};
 int ta2[6] = {0,2,4,6,8,17};
 int *tres = sort_fus(ta1,8,ta2,6);
 for(int i = 0; i<14;i++)
 {
 	printf("%d ",tres[i]);
 }
 printf("\n");
 return 0;
 
}

