#include "liste_entiers.h"

int main() {
int val_rech;
  cellule_t *ma_liste=creerListe(10);
  AfficherListeInt(ma_liste);
  //printf("Entrez la valeur à rechercher\n");
  //scanf("%d", &val_rech);
  //printf("Le nombre de fois que la valeur %d apparait dans la liste est :%d\n",val_rech,nb_occurences(val_rech,ma_liste));
  printf("Donnée à la position %d : %d\n", 2, Renvoyer_val_element_pos(2, ma_liste));
  printf("Il y a %d occurences du max \n",nb_maximum(ma_liste));
  return 0;
}
