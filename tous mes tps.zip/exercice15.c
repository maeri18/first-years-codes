#include<stdio.h>
#include<cini.h>
#include<math.h>

void triangle(int h, int l)
{
	CINI_draw_line(l/2, 0, l-1, h-1, "green");
	CINI_draw_line(l/2, 0, 0, h-1, "blue");
	CINI_draw_line(0, h-1, l-1, h-1, "red");
	CINI_loop();
}

void triangles(int h, int l)
{
	CINI_draw_line(l/2, 0, l-1, h-1, "green");
	CINI_draw_line(l/2, 0, 0, h-1, "blue");
	CINI_draw_line(0, h-1, l-1, h-1, "red");
	CINI_draw_line((9*l)/20, (h-1)/10, (19*l-18)/20, (9*(h-1))/10, "green");
	CINI_draw_line((9*l)/20, (h-1)/10, (l-1)/10, h-1, "blue");
	CINI_draw_line((l-1)/10, h-1, (19*l-18)/20, (9*(h-1))/10, "red");
	CINI_loop();
}

void triangles1(int h, int l)
{
	float xA = l/2 , yA = 0, xB = l-1, yB = h-1 , xC = 0, yC = h-1;
	int i;
	for(i=0;i<10;i++)
	{
		CINI_draw_line(xA,yA,xB,yB,"green");
		CINI_draw_line(xA,yA,xC,yC,"blue");
		CINI_draw_line(xB,yB,xC,yC,"red");
		
		CINI_loop_until_keyup();
		
		xA = (9*xA + xC) / 10;
		yA = (9*yA + xC) / 10;
		xB = (9*xB + xA) / 10;
		yB = (9*yB + yA) / 10;
		xC = (9*xC + xB) / 10;
		yC = (9*yC + yB) / 10;
	}
}

void triangles2(int h, int l, float eps)
{
	float xA = l/2 , yA = 0, xB = l-1, yB = h-1 , xC = 0, yC = h-1;
	float d = sqrt((xB-xA)*(xB-xA) + (yB-yA) * (yB-yA));
	while(d>eps)
	{
		CINI_draw_line(xA,yA,xB,yB,"green");
		CINI_draw_line(xA,yA,xC,yC,"blue");
		CINI_draw_line(xB,yB,xC,yC,"red");
		xA = (9*xA + xC) / 10;
		yA = (9*yA + xC) / 10;
		xB = (9*xB + xA) / 10;
		yB = (9*yB + yA) / 10;
		xC = (9*xC + xB) / 10;
		yC = (9*yC + yB) / 10;
		d = sqrt((xB-xA)*(xB-xA) + (yB-yA) * (yB-yA));
	}
	CINI_loop();
}

int main()
{
	CINI_open_window(2000,2000,"fourth");
	CINI_fill_window("white");
	triangles2(2000,2000,0.1);
	return 0;
}
	 
