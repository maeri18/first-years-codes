#include<stdio.h>
float prixEntree(int nbre_adulte, int nbre_enfants)
{
	int new_adulte , new_enfants;
	if ((nbre_adulte-2) > 0)
	{ new_adulte = nbre_adulte-2;}
	else
	{ new_adulte = 0;}
	if((nbre_enfants-3)>0)
	{new_enfants = nbre_enfants-3;}
	else
	{new_enfants =0;} 
	float prix1 = nbre_adulte * 22.7 + nbre_enfants * 10.75; // prix sans l'offre "Famille"
	float prix2 = 57.8 + (new_adulte)*22.7 + new_enfants *10.75; //prix avec l'offre "Famille"
	if (prix1>prix2)
	{return prix2;}
	else
	{return prix1;}
}
int main()
{
	printf("Pour 5 adultes et 3 enfants : %f livres\n",prixEntree(5,3));
	printf("Pour 2 adultes et 3 enfants : %f livres\n",prixEntree(2,3));
	printf("Pour 2 adultes et 2 enfants : %f livres\n",prixEntree(2,2));
	printf("Pour 2 adultes et 1 enfants : %f livres\n",prixEntree(2,1));
	printf("Pour 1 adultes et 3 enfants : %f livres\n",prixEntree(1,3));
	printf("Pour 7 adultes et 2 enfants : %f livres\n",prixEntree(7,2));
	return 0;
}
	
