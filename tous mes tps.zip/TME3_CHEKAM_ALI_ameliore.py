import random
import math
#exercice_3.8

#Question 1
def lancer_de6()->int:
    """renvoie une valeur entiere aleatoire comprise entre 1 et 6"""
    x : float = random.random()
    return math.floor((x * 6) +1)


#Question_2
#jeu de tests
random.seed(11)
assert lancer_de6()== 3
assert lancer_de6() == 4
random.seed(42)
assert lancer_de6() == 4
assert lancer_de6() == 1
assert lancer_de6() == 2

#question 3
def moyenne_plusieurs_lancers(n : int) -> float:
    """ précondition : n>0
    """
    somme : int = 0
    i : int = 0
    
    while i<n:
        somme = somme + lancer_de6()
        i = i + 1
    return somme/n


random.seed(11)
assert moyenne_plusieurs_lancers(2) == 3.5
random.seed(42)
assert moyenne_plusieurs_lancers(3) == 7/3

#Question 4
def frequence_valeur (r:int, n:int) ->float:
    """précondition : r>=1 and r<=6
        précondition : n>=0
        """
    i : int = 0
    lancer : int
    nb_apparition : int = 0
    while i<n:
        lancer = lancer_de6()
        if(lancer == r):
            nb_apparition = nb_apparition + 1
        i = i+1
    return nb_apparition/n

assert frequence_valeur(1,1) == 0.0
#assert frequence_valeur(1,10) == 0.2
#assert frequence_valeur(1,100) == 0.13

#question subsidiaire: La generation des valeurs aleatoires ne suit pas une loi uniforme

#question 5
def lancer_deN(n: int) -> int:
    """précontion : n>0
    renvoie une valeur entiere aleatoire comprise entre 1 et n"""
    x : float = random.random()
    return math.floor((x * n) +1)

assert 1 <= lancer_deN(20) <=20
assert 1<= lancer_deN(8) <=8
assert lancer_deN(1) == 1



#Exercice 4.5
#Question 1
def nb_couples_intervalle(n : int, p:int) -> int :
    """précondition : n<=p
renvoie le nombre de  couples situés entre n et p
"""
    i :int  = n
    nbre : int = 0
    while i<=(p-1):
        nbre = nbre + p-i
        i = i+ 1

    return nbre

assert nb_couples_intervalle(0,0) == 0
assert nb_couples_intervalle(2,4) == 3
assert nb_couples_intervalle(-1,3) == 10
    

#question 2
def nb_couples_divise(n :int, p : int) ->int :
    """ précondition : n<=p"""
    j :int = n + 1
    i : int = n
    nbre : int = 0
    while j<=p:
        i = n 
        while i<j:
            if i != 0 and j%i==0:
                nbre = nbre + 1
            i=i+1
        j = j+1
    return nbre

assert nb_couples_divise(4,6) == 0
assert nb_couples_divise(2,6) == 3
assert nb_couples_divise(-1,1) == 2
assert nb_couples_divise(1,10) == 17
assert nb_couples_divise(0,4)== 4
    
#question 3
def nb_couples_divise_trace(n :int, p : int) ->int :
    """ précondition : n<=p"""
    j :int = n + 1
    i : int =  n
    nbre : int = 0
    while j<=p:
        i = n 
        while i<j:
            print("couple ( ",i," , ",j," )")
            if i!=0 and j%i==0:
                nbre = nbre + 1
                print("------------")
                print(i, " divise ", j,"!")
                print("------------")
            i = i + 1
        j = j+1
    return nbre

assert nb_couples_divise_trace(4,6) == 0
assert nb_couples_divise_trace(2,6) == 3
assert nb_couples_divise_trace(-1,1) == 2
assert nb_couples_divise_trace(1,10) == 17

#Question 4

def existe_couples_divise_rapide(n:int, p:int) -> bool:
    """precondition : n<=p"""
    i:int
    j:int = n+1
    nbre : int =0
    cond : bool = False
    while j!=p+1 and cond !=True:
        i=n
        while i!=j and cond !=True:
            if i!=0:
                if j%i==0:
                    nbre = nbre + 1
                    cond = True
            i = i +1
        j = j+1
    return cond
assert existe_couples_divise_rapide(0,0) == False
assert existe_couples_divise_rapide(-1,0) == True
assert existe_couples_divise_rapide(17,27) == False
assert existe_couples_divise_rapide(0,1) == False
assert existe_couples_divise_rapide(3,10) == True
assert existe_couples_divise_rapide(-1,1) == True


#Question 5
def existe_couples_divise_sortie_fonction_anticipee(n:int,p:int) ->bool:
    """precondition : n<=p"""
    i:int
    j:int=n+1
    nbre:int=0
    while j!=p+1:
        i=n
        while i!=j:
            if i!=0:
                if j%i==0:
                    nbre = nbre +1
                    return True
            i=i+1
        j=j+1
    return False
assert existe_couples_divise_sortie_fonction_anticipee(0,0) == False
assert existe_couples_divise_sortie_fonction_anticipee(-1,0) == True
assert existe_couples_divise_sortie_fonction_anticipee(-1,1) == True
assert existe_couples_divise_sortie_fonction_anticipee(0,1) == False
assert existe_couples_divise_sortie_fonction_anticipee(17,27) == False
assert existe_couples_divise_sortie_fonction_anticipee(3,10) == True
assert existe_couples_divise_sortie_fonction_anticipee(2,6) == True

#exercice 3.5

#Question 1
import math
def fibonacci(n:int)->float:
    """precondition : n>=0
    """
    F0 : float = 0
    F1 : float = 1
    Fn: float 
    i :int = 2
    j:int = n
    if j==0 :
        return 0
    if j==1:
        return 1
    else:
##        Fn = F0 + F1
        while i!=n+1:
            Fn = F1 + F0
            F0 = F1
            F1 = Fn
            i = i+1
        return Fn
    
assert fibonacci(0)==0
assert fibonacci(1)==1
assert fibonacci(2)==1
assert fibonacci(3)==2
assert fibonacci(4)==3
assert fibonacci(5)==5
assert fibonacci(6)==8
assert fibonacci(7)==13
assert fibonacci(8)==21

#Question 2
#F(8) = 21

#Question 3
def fibo_diff(k:int)->float:
    """precondition: k>=2
"""
    return(fibonacci(k)/fibonacci(k-1))
    
assert fibo_diff(2)== 1.0
assert fibo_diff(3)== 2.0
assert fibo_diff(4)== 3/2

#Question 4

def fibo_approx(k:int)->float:
    """ precondition: k > 0"""
    return (((1+math.sqrt(5))/2)**k)/math.sqrt(5)

##jeu de tests : Pour tester ma fonction, je propose d'ecrire des jeux de tests basés sur la fonction round, qui va arrondir la, valeur donnée par fibo_approx. On comparera ensuite le résultat à celui donné par la fonction fibonacci
assert round(fibo_approx(5)) == fibonacci(5)
assert round(fibo_approx(1)) == fibonacci(1)
assert round(fibo_approx(51)) == fibonacci(51)

        
   
    
