#include <stdio.h>
#include <stdlib.h>
#include "liste_entiers.h"

cellule_t * creerListe(int n) {
/* cree une liste de n entiers saisi par l'utilisateur
  renvoie l'adresse du premier element de la liste */
  int i;
  int val;
  cellule_t *tete=NULL;
  cellule_t *ptr;
  
  printf("Saisie des %d elements de la liste\n",n);
  for (i=0; i < n; i++) {
    printf("Element %d :",i+1);
    scanf("%d",&val);
    ptr=malloc(sizeof(cellule_t));
    ptr->donnee = val;
    ptr->suivant = tete;
    tete = ptr;
  }
  return tete;
}

void AfficherListeInt(cellule_t * liste)
{
	cellule_t * tmp = liste;
	while(tmp)
	{
		printf("%d ", tmp->donnee);
		tmp = tmp->suivant;
	}
	printf("\n");
}
int nb_occurences(int val, cellule_t * liste)
{
	int cmpt = 0;
	cellule_t * L = liste;
	while(L)
	{
		if(L->donnee == val)
		{
			cmpt++;
		}
		L=L->suivant;
	}
	return cmpt;
}

int tous_plus_grand(int val, cellule_t * liste)
{
	cellule_t * tmp = liste;
	while(tmp)
	{
		if(tmp->donnee < val)
		{
			return 0;
		}
		tmp = tmp->suivant;
	}
	return 1;	
}
cellule_t * Maximum(cellule_t * liste)
{
	cellule_t * tmp =liste;
	int max;
	cellule_t * max_p = NULL;
	if(!liste)
	{
		return NULL;
	}
	else
	{
		max = tmp -> donnee;
		max_p = tmp;
		tmp = tmp->suivant;
		while(tmp)
		{
			if(tmp->donnee > max)
			{
				max= tmp->donnee,
				max_p = tmp;
			}
			tmp = tmp -> suivant;
		}
		return max_p;
	}
}
cellule_t * Renvoyer_val_element_pos_mine(int pos, cellule_t* liste)
{
	if(pos<0 || liste == NULL)
	{
		return NULL;
	}	
	else
	{
		
		cellule_t * tmp = liste;
		while(pos > 0 && tmp !=NULL)
		{
			tmp = tmp -> suivant;
			pos--;
		}
		if(!tmp)
		{
			return NULL;
		}
		else
		{
			return tmp;
		}
		
	}		
}
 int  Renvoyer_val_element_pos(int pos, cellule_t* liste)
 {
 	cellule_t * tmp = liste;
	while(pos > 0 && tmp !=NULL)
	{
		tmp = tmp -> suivant;
		pos--;
	}
	return tmp->donnee;	
 }
 cellule_t * Concatener_it(cellule_t * liste1, cellule_t * liste2)
 {
 	if(!liste1)
 	{
 		return liste2;
 	}
 	else if(!liste2)
 	{
 		return liste1;
 	}
 	else
 	{
 		cellule_t * tmp = liste1;
 		while(tmp->suivant)
 		{
 			tmp = tmp->suivant;
 		}
 		tmp->suivant = liste2;
 		return liste1;
 	}
 }
int nb_maximum(cellule_t * liste)
{
	cellule_t* tmp = liste;
	int cmpt = 1;
	cellule_t * max_p;
	if(!liste)
	{
		return 0;
	}
	else
	{
	
		
		max_p = tmp;
		tmp = tmp -> suivant;
		while(tmp)
		{
			if(tmp->donnee > max_p->donnee)
			{
				cmpt = 1;
				max_p = tmp;	
			}
			else if(tmp->donnee == max_p->donnee)
			{
				cmpt++;
			}
			tmp = tmp->suivant;
		}
		return cmpt;
	}
}
 
