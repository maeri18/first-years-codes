#Activité  5
#Partie guidée
#question 1
def degre (p:List[int])->int:
    """renvoie le dégré du polynome représenté par la liste p"""
    i:int
    degre : int = 0
    for i in range (len(p)):
        if p[i]!=0:
            degre=i
    return degre
assert degre([3, 0, 2])==2
assert degre([])==0
assert degre([3,4,5,100,0, 0])==3
assert degre([0,0,0, 0])==0

#question2:
def somme(p:List[int], q:List[int])->List[int]:
    """effectue la sp """
    d:List[int]=[]
    i:int
    j:int
    if len(p)<len(q):
        for i in range (len(p)):
            d.append(p[i]+q[i])
        d=d+q[len(p):len(q)]
    else:
        for j in range (len(q)):
            d.append(p[j]+q[j])
        d=d+p[len(q):len(p)]
    return d
assert somme([3, 0, 2],[])==[3, 0, 2]
assert somme([3, 0, 2],[4,5,0,2])==[7,5,2,2]
assert somme([0, 0, 0],[])==[0,0,0]
assert somme([3, 0, 2],[2,-5,0])==[5,-5,2]

#question 3
def normalise(p:List[int])->List[int]:
    """ renvoie la forme normalisée de p"""
    if p==[] or (p[0]== 0 and degre(p)==0) :
        return []
    return p[:degre(p)+1]
                         
assert normalise([2,3,5,0,0,0])==[2,3,5]
assert normalise([2,3,0,0,4,0])==[2,3,0,0,4]
assert normalise([0,0,5,0,0,0])==[0,0,5]
assert normalise([1,3,8,2])==[1,3,8,2]
assert normalise([0,0,0,0])==[]
assert normalise([1,0,0])==[1]
assert normalise([])==[]

#question 4

def produit(p:List[int], q:List[int])->List[int]:
    """renvoie le produit des polynomes p et q"""
    q1:List[int]=normalise(q)
    p1:List[int]=normalise(p)
    j:int
    i:int
    k:int
    lres : List[int]=[]
    for k in range(int(abs(len(q1)-len(p1)))):
        if (len(p1)<len(q1)):
            p1.append(0)
        else:
            q1.append(0)
    for i in range(1,degre(p1) + degre(q1)):
        for j in range(1,i+1):
            lres.append(p1[j]*q1[i-j] + q1[i]*p1[i-j])
    return lres
        
        

