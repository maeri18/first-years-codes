#include <stdio.h>
#include <assert.h>

int alternative(int n1, int n2, int n3) {
  int res ;
	
  if (n1 > 8) {
    res = 3;
  } else {
    if (n3 == 20) {
      res = 2;
    } else {
      if ((n2 >= 10) && (n3 >= 10)) {
        res = 1;
      } else {
        res = 0;
      }
    }
  }
  
  return res;
}

int main(){
  assert(alternative(12,9,0)==3); // cas ou on retourne 3 
  assert(alternative(4,9,20)==2); // cas ou on retourne 2
  assert(alternative(5,12,10)==1);//cas ou on retourne 1
  assert(alternative(-9,9,30)==0);//cas ou on retourne 0
  

  return 0;
}
