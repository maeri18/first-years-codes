#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#define NBTOURS 5
#define NBLANCERS 2
#define NBQUILLES 10

/* Il sera probablement n�cessaire de modifier les parametres et valeur de retour des fonctions 
  lancer, lancer_aleatoire, score et jeu */

/* Les declarations actuelles permettent de compiler et d'executer le programme */

int lancer(int nb) 
{
 int d;
 do 
 {
  printf("Entrez une valeur contenue entre 0 et %d \n\n", nb);
  scanf("%d",&d);
 }
 while(d>nb || d<0);
  return d;
}

int lancer_aleatoire() {
  return 0;
}

void score(int *points, int* spare, int* strike,int lancer) 
{
 //*points = *points + lancer;
 if (*spare==1)
 {
 *points  = *points  + lancer ;
 *spare = 0;
 }
 else if(*strike==2)
 {
 *points  = *points  + lancer;
 *strike = 1;
 }
 else if(*strike == 1)
 {
 *points  = *points  + lancer;
 *strike = 0;
 }

}

void tour(int lancer1, int*spare, int*strike, int*points)
{
	int lancer2;
	*points = *points + lancer1;
	printf("Quilles renversees : %d\n",lancer1);
	if (lancer1==NBQUILLES)
	{
		*strike = 2;
	}
	else if(lancer1<NBQUILLES)
	{
		lancer2 = lancer(NBQUILLES-lancer1);
		printf("Quilles renversees : %d\n",lancer2);
		*points = *points + lancer2;
		if(lancer2+lancer1 == NBQUILLES)
		{
		 *spare = 1;
		}
	}
}

int jeu() 
{
int spare=0, strike=0, points=0, lancer1,quilles=NBQUILLES;
int i=0;
while(i<NBTOURS)
{
	lancer1=lancer(quilles);
	score(&points, &spare, &strike, lancer1);
	tour(lancer1,&spare,&strike,&points);
	printf("Score apres le tour %d : %d \n",i+1,points);	
	if((i==NBTOURS-1) && (spare ==1))
	{
	lancer1=lancer(quilles);
	points = points + lancer1;
	printf("Score tour supplementaire spare : %d \n",points);
	}
	if((i==NBTOURS-1) && (strike==2))
	{
	lancer1=lancer(quilles);
	points = points + lancer1 + lancer(quilles-lancer1);
	printf("Score tours supplementaires strike : %d \n",points);
	}
	i=i+1;
}
return points;
}	

int main() {
  srand(time(NULL));
  
  jeu(); 
  return 0;
}
