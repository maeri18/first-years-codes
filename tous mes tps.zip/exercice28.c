#include<stdio.h>
#include<stdlib.h>
#include<time.h>
#define NB_AMIS 5
#define NB_JOURS 10
#define MONTANT_MIN 30
#define MONTANT_MAX 50

void init (float tab[NB_AMIS][NB_JOURS])
{
	for(int i=0; i<NB_AMIS;i++)
	{
		for(int j=0;j<NB_JOURS;j++)
		{
			tab[i][j]=0.0;
		}
	}
}
void comptes_jour(float tab[NB_AMIS][NB_JOURS],int j)
{
	float depenses = rand()%(MONTANT_MAX-MONTANT_MIN+1)+MONTANT_MIN;
	int payeur = rand()%(NB_AMIS);
	float individuel=depenses / NB_AMIS;
	for(int i = 0; i<NB_AMIS;i++)
	{
		if(i==payeur)
		{
			tab[i][j] = depenses - individuel;
		}
		else
		{
			tab[i][j]=-individuel;
		}
	}
}

void affiche_tab(float tab[NB_AMIS][NB_JOURS])
{
	for(int i=0;i<NB_JOURS;i++)
	{
		for(int j=0;j<NB_AMIS;j++)
		{
			if(tab[j][i]>0)
			{
				printf("Jour %d : %d paye %.0f\n", i+1, j, (tab[j][i]*NB_AMIS)/(NB_AMIS-1));
			} 
		}	
	}
	printf("\t|");
	for(int j = 0;j<NB_JOURS;j++)
	{
		printf("\t%d",j+1);
	}
	printf("\n----------------------------------------------------------------------------------------------------------------------------------------------------------\n");
	for(int i=0;i<NB_AMIS;i++)
	{
		printf("%d\t|\t",i);
		for(int j=0;j<NB_JOURS;j++)
		{
			printf("%.2f\t",tab[i][j]);
		}
		printf("\n");
	}
}
float solde_id(float tab[NB_AMIS][NB_JOURS],int id)
{
	float res=0;
	if(id<NB_AMIS && id>=0)
	{
		for(int j=0; j<NB_JOURS;j++)
		{
			res = res + tab[id][j];
	        }
	        return res;
	}
	
	exit(1);
	
}
int main()
{	srand(time(NULL));
	float tab[NB_AMIS][NB_JOURS];
	init(tab);
	for(int j=0;j<NB_JOURS;j++)
	{
	comptes_jour(tab,j);
	}
	affiche_tab(tab);
	printf("\n--------A present, les comptesss !!!------\n\n");
	for(int i=0;i<NB_AMIS;i++)
	{
		printf("\n%d : ",i);
		float d = solde_id(tab,i);
		if(d==0)
		{
			printf("C'est bon t'es reglo mec\n");
		}
		else if(d<0)
		{
			printf("Tu dois rembouser %.2f \n",-d);
		}
		else
		{
			printf("Bro, les autres te doivent %.2f\n",d);
		}
	}
	return 0;
	
}
