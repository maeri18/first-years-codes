#include<stdio.h>
//Question 1
void echange(int * a, int *b)
{
	int permut = *a;
	*a=*b;
	*b=permut;
}
//Question 2
void tri(int *first, int *second)
{
if (*first>*second)
{
	echange(first,second);	
}
}
void tri_3(int *a, int*b, int*c)
{
for(int i=0; i<2; i++)
{
	tri(a,b);
	tri(a,c);
	tri(b,c);
	
}
}
int main()
{
	/*//test echange
	int a=3, b=4;
	printf("Test echange\n");
	printf("Avant l'appel a = %d, b = %d \n",a,b);
	echange(&a,&b);
	printf("Apres l'appel a = %d, b = %d \n",a,b);
	//test tri 
	printf("Test Tri Numero 1\n");
	int c=7, d=-15;
	printf("Avant l'appel c= %d, d = %d \n",c,d);
	tri(&c,&d);
	printf("Apres l'appel c= %d, d = %d \n",c,d);
	printf("Test Tri Numero 2\n"); 
	printf("Avant l'appel c= %d, d = %d \n",c,d);
	tri(&c,&d);
	printf("Apres l'appel c= %d, d = %d \n",c,d);*/
	//test tri_3
	int e=4, f=5, g=3;
	printf("Test tri_3\n");
	printf("Avant l'appel a= %d, b = %d, c = %d  \n",e,f,g);
	tri_3(&e,&f,&g);
	printf("Avant l'appel a= %d, b = %d, c = %d  \n",e,f,g);
	
	return 0;

}
