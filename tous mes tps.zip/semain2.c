//exercice9
#include <cini.h>
#include <stdio.h>
#include <assert.h>
//question1 et 2
 void diagonale(float x){
 int i;
 for(i=0; i<=x;i++){
 	CINI_draw_pixel(0, i, "red");  
 	}
 }


// exercice10
// question1
void carres (float l){
	for(int i=0; i<=l;i++){
 	CINI_draw_pixel(0, i, "red");  
 	}
 	for(int i=0; i<=l;i++){
 	CINI_draw_pixel(i, l, "green");  
 	}
 	for(int i=0; i<=l;i++){
 	CINI_draw_pixel(l, i, "white");  
 	}
 	for(int i=0; i<=l;i++){
 	CINI_draw_pixel(i, 0, "blue");  
 	}
}

// QUESTION2
void carres2(float l,int x, int y){
	for(int i=0; i<=l;i++){
 	CINI_draw_pixel(x, y+i, "red");  
 	CINI_draw_pixel(l+x,y+i, "white");  
 	CINI_draw_pixel(x+i, l+y, "green");  
 	CINI_draw_pixel(x+i, y, "blue");  
 	}
 	}
// question4

void Carresremontant (int l, int s, int y){
	int a=s, b=y;
	while(b>=0)
	{
	carres2(l,a,b);
	a=a-20;
	b=b-20;
	}
	}



//EXERCICE11

int jours(int nb_pers ,int nb_pop ,float pers_cont){
	// 0.0<=nb-pers<=100.00
	int nb_jours=0;
	int nb_pers_cont=1;
	float pour_pop=(nb_pers_cont*100)/nb_pop;
	while (pour_pop<pers_cont){
		nb_jours=nb_jours+1;
		nb_pers_cont=nb_pers_cont+(nb_pers_cont)*nb_pers;
		pour_pop=(nb_pers_cont*100)/nb_pop;
	}
	return nb_jours;
}	

// question2

float pourcentage(int nb_pers_cont1 , int  pop, int nb_jours){
    int j=1;
    int nb_pers_cont=1;
    while(j<=nb_jours){
    	nb_pers_cont=nb_pers_cont + (nb_pers_cont* nb_pers_cont1);
    	j=j+1;
    }
    return (nb_pers_cont*100)/(float)pop;  
 }
 		

	
//exercice14
#define TFAMILLE 57.8
#define TADULTE 22.7
#define TENFANT 10.75

 float prixEntree(int nb_a, int nb_e){
 float somme=0;
 float tarif = TADULTE* nb_a + TENFANT *nb_e;
 int nb =0;
 int enf3 = nb_e;
 int ad3 = nb_a;
 	 while (enf3 >=3 && ad3 >=2){
 	  nb=nb+1;
 	  enf3=enf3-3;
 	  ad3= ad3-2;
 	 }
 	 if (( 22.7*(ad3) + 10.75*(enf3)) > 57.8 && enf3>0){
 	 somme=somme+ 57.8 * nb +57.8;
 	 }
 	 if(( 22.7*(ad3) + 10.75*(enf3)) < 57.8 || enf3==0){
 	 	somme=somme + ( TADULTE *(ad3) + TENFANT*(enf3))+ 57.8*nb ;
 	 	}
 	 /*else {
 	 somme=somme + ( TADULTE *(ad3) + TENFANT*(enf3))+ 57.8*nb ;
 	 }*/
 
 	/*if( ((nb_e <= 3) &&  (nb_a <=2)) || (nb_e>=3) || (nb_a >=2) || (nb_e<2) || (nb_a<2)){
 		somme = somme + TFAMILLE ;
 		}	
 	int enf2= nb_e-3;
 	int ad2= nb_a-2;
 	 if(enf2<0){
 	 	enf2=0;
 	 	}
 	 if(ad2<0){
 	 	ad2=0;
 	 	}
 	 if(enf2>=0 || ad2>=0){
 		somme=somme+enf2*TENFANT  + ad2*TADULTE ;
 		}*/
 	if(tarif> somme){
 		return somme;
 	}
 	return tarif;
}
int main() {

/*printf("%f \n", pourcentage(5,10000,2));
  CINI_open_window(400, 300, "test");
  Carresremontant(150,80,80);
  //carres(200); affichage question1 exo10
  //carres2(200 , 50,60); affichage question2 exo10
  //diagonale(200); affichage question3 exo9
  CINI_draw_pixel(199, 200, "white");    affiche pt coord x=199, y=200
  CINI_draw_pixel(200, 200, "white");   affiche pt coord x=200, y=200
  CINI_draw_pixel(201, 200, "white");   affiche pt coord x=201, y=200
  CINI_loop();
  assert (jours(5,10000,100.00)==6);
  assert (jours(5,10000,50.00)==5);
  assert (jours(5,10000,25.00)==5);
  assert (jours(5,10000,10.00)==4);*/
  
 printf("%f \n",prixEntree(6,8));
 printf("%f \n",prixEntree(2,1));
 printf("%f \n",prixEntree(2,2));
 printf("%f \n",prixEntree(2,3));
 printf("%f \n",prixEntree(6,3));
 printf("%f \n",prixEntree(1,3));
 return 0;
}			
