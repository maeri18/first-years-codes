// Question 1
#include<stdio.h>
float prixEntree(int ad,int enf)
{
	float somme;
	float tarif_normal = 22.7 * ad + 10.75 * enf;
	
	int ad2 = ad / 2;
	int enf2 = enf/3;
	
	
	int ad3 = ad - enf2 * 2;
	int enf3 = enf - ad2*3;
	if (ad3 <=0) { ad3 = 0;}
	if (enf3<=0) {enf3 = 0;}
	

	if(ad2<enf2)
	{	if (ad2 ==0) { somme =  57.8  + (enf3-3) * 10.75;}
	else
	{
		if ((((ad%2)*22.7 + (enf3) * 10.75) > 57.8)&&(enf3<=3))
		{ somme = ad2*57.8 + 57.8;}
		else
		{somme = ad2 * 57.8 + (ad%2)*22.7 + (enf3) * 10.75;}
		
	}
	}
	else
	{
	if (enf2==0) {somme =  57.8 + (ad3-2)*22.7 ;}
	else
	{
		if ((((ad3)*22.7 + (enf%3) *10.75)> 57.8)&&(ad3<=2))
		{somme = enf2*57.8 + 57.8;}
		else
		{somme  = enf2 * 57.8 + (ad3)*22.7 + (enf%3) *10.75;}
	}
	}
	
	if (somme < tarif_normal)
	return somme;
	
	return tarif_normal;
		
}

int main()
{
	printf(" Pour %d adultes et %d enfants : %.2f \n", 2,1,prixEntree(2,1));
	printf(" Pour %d adultes et %d enfants : %.2f \n", 2,2,prixEntree(2,2));
	printf(" Pour %d adultes et %d enfants : %.2f \n", 2,3,prixEntree(2,3));
	printf(" Pour %d adultes et %d enfants : %.2f \n", 6,3,prixEntree(6,3));
	printf(" Pour %d adultes et %d enfants : %.2f \n", 1,3,prixEntree(1,3));
	printf(" Pour %d adultes et %d enfants : %.2f \n", 5,7,prixEntree(5,7));
	printf(" Pour %d adultes et %d enfants : %.2f \n", 6,8,prixEntree(6,8));
	printf(" Pour %d adultes et %d enfants : %.2f \n", 10,0,prixEntree(10,0));
	printf(" Pour %d adultes et %d enfants : %.2f \n", 0,4,prixEntree(0,4));
	return 0;
	
}

