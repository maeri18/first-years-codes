#include<stdio.h>
#define nb 5
void conversion(int tabF[],float *tabC, size_t len) 
{
	for(int i = 0; i<len; i++)
	{
		tabC[i] = (tabF[i] - 32) * (5.0/9);
	}
}

int main() {
   int tabF[nb];
   float tabC[nb];
   int i;
   
   for (i = 0; i < nb; i++) {
      scanf("%d", &tabF[i]);
   }
   
   conversion(tabF,tabC,nb);
   for (i = 0; i < nb; i++) {
      printf("%f  ", tabC[i]);
   }
   printf("\n");
   return 0;
}
