#include<stdio.h>
#include<assert.h>

int signeProduit(int a , int b)
{
	if ((a>0 && b>0)||(a<0 && b<0))
	{
		return 1;
	}
	else if (a==0 || b==0)
	{
		return 0;
	}
	return -1;
	
}

int main()
{
	assert(signeProduit(2,3)==1);
	assert(signeProduit(-1,0)==0);
	assert(signeProduit(-1,-7)==1);
	assert(signeProduit(-1,3)==-1);
	assert(signeProduit(0,0)==0);
	assert(signeProduit(5,-8)==-1);
	return 0;
}
