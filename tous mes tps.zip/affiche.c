#include<stdio.h>
#include<stdlib.h>
element_t* ajout_suivant(element_t* element, int val, int freq) 
{
	if(element
    element_t* cell = malloc(sizeof(element_t));
    if(!cell)
    {
        return NULL;    
    }
    cell->valeur = val;
    cell->frequence = freq;
    cell->suivant = element->suivant;
    element->suivant = cell;
    return cell;
}

int main() {
   int val, freq;
   scanf("%d", &val);
   scanf("%d", &freq);
   element_t* prems = ajout_suivant(NULL, val, freq);
   scanf("%d", &val);
   scanf("%d", &freq);
   element_t* deuz = ajout_suivant(prems, val, freq);
   scanf("%d", &val);
   scanf("%d", &freq);
   if (val < deuz-> valeur) {
      ajout_suivant(prems, val, freq);
   }
   else {
      ajout_suivant(deuz, val, freq);
   }
   affiche_ensemble(prems);
   return 0;
}
