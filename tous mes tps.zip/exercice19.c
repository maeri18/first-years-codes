#include <stdio.h>
#define VAL1 2
#define VAL2 7
#define VAL3 5
#define VAL4 9


void min_max(int *min, int*max, int val) 
{
	if (val>*max)
	{
		*max = val;
	}
	if (val<*min)
	{
		*min = val;
	}
}

void stats (int v1, int v2, int v3, int v4, int * max, int*min, float * moyenne) 
{
	if (v1<=0)
	{
		*max = -1;
		*min = -1;
		*moyenne = -1.0;
	}
	else 
	{
		*max=v1;
		*min=v1;
		*moyenne = v1;

		if (v2>0)
		{
			min_max(min,max,v2);
			*moyenne = (v1+v2)/2.0;
			if(v3>0)
			{
				min_max(min,max,v3);
				*moyenne = (v1 + v2 + v3)/3.0;
				if(v4>0)
				{
					min_max(min,max,v4);
					*moyenne = (v1+v2+v3+v4)/4.0;
				}
			}

		}

	}

}

void afficher_resultat(float moyenne, int min, int max) {
  printf("max = %d, min = %d, moy = %.2f\n",max,min,moyenne);
}

int main() {

  float moy;
  int min, max;
  /* TESTS STATS()
  stats(2,7,5,9,&max,&min,&moy);
  printf("v1=2, v2=7, v3=5, v4=9, maximum = %d, minimum = %d, moyenne = %.2f\n\n",max,min,moy);
  moy=0; max=0; min=0;
  stats(2,7,-5,-9,&max,&min,&moy);
printf("v1=2, v2=7, v3=-5, v4=-9, maximum = %d, minimum = %d, moyenne = %.2f (seules les valeurs 2 et 7 sont prises en compte)\n",max,min,moy);
moy=0; max=0; min=0;
  stats(2,7,-5,9,&max,&min,&moy);
printf("v1=2, v2=7, v3=-5, v4 =9, maximum = %d, minimum = %d, moyenne = %.2f (seules les valeurs 2 et 7 sont prises en compte)\n\n",max,min,moy);
moy=0; max=0; min=0;
  stats(2,-7,-5,9,&max,&min,&moy);
printf("v1=2, v2=-7, v3=-5, v4 =9, maximum = %d, minimum = %d, moyenne = %.2f (seule la valeur 2 est prise en compte)\n",max,min,moy);
moy=0; max=0; min=0;
  stats(-2,-7,-5,9,&max,&min,&moy);
printf("v1=-2, v2=-7, v3=-5, v4 =9,maximum = %d, minimum = %d, moyenne = %.2f (aucune valeur prise en compte)\n\n",max,min,moy);*/


  stats(VAL1,VAL2,VAL3,VAL4,&max,&min,&moy);
  
 
  afficher_resultat(moy,min,max);
  
  return 0;
}
