import random
def motedepasse()->str:
    """ génère des mots de passe"""
    i:int = input("entrez le nombre")
    ens_car  : str ="abcdefghujklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789!#$%&\()*+,-./:;<=>?@[\\]^_"
    res:str=''
    j:int=1
    while j<=i:
        res = res + ens_car[random.randint(0,len(ens_car))]
    return res
