#include<stdlib.h>
#include<stdio.h>
#define NB_PLANETES 8



//Question 1
typedef struct planet
{
	char nom[11];
	float densite;
	float distance;
	int satellite;
}planete;

void affiche_planete(planete p)
{
	printf("Nom : %s\n",p.nom);
	printf("Densite :%.2f\n",p.densite);
	printf("Distance : %.2f\n",p.distance);
	printf("Satellite : %d\n",p.satellite);
	printf("\n");
}

void afficheToutesPlanetes(planete tab[],int len)
{
	for(int i=0;i<len;i++)
	{
		affiche_planete(tab[i]);
	}
}

void modifieDensite(planete * p,float d_new)
{
	p->densite = d_new;
}


int main(){
    planete systemeSolaire[NB_PLANETES] ={{"Mercure", 5.42, 58, 0},{"Venus", 5.25, 108.2, 0},{"Terre", 5.52,149.6,1},{"Mars",3.94,227.9,2},{"Jupiter",1.314,778.3,16},{"Saturne",0.69,1427,17},{"Uranus",1.19,2869,15},{"Neptune",1.6,4496,2}};
    afficheToutesPlanetes(systemeSolaire,NB_PLANETES);
    modifieDensite(&systemeSolaire[0],7.0);
    afficheToutesPlanetes(systemeSolaire,NB_PLANETES);
    
            
    return 0;
}
