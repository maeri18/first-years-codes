#include <cini.h>
 
void diagonale(int x)
{ // précondition: (x,x) appartient à la fenêtre
int i;
for(i=0;i<=x;i++)
{
	CINI_draw_pixel(i,i,"pink");
}
CINI_loop();
}


int main() {
 
  CINI_open_window(1300, 1300, "test");
  CINI_fill_window("black");
    
  diagonale(1299);
  
  return 0;
}

