#include <stdio.h>
#include <math.h>
#include<assert.h>
float discriminant(int a, int b, int c)
{
	return (float)(b*b-4*a*c);
}
void afficheRacines(int a, int b, int c)
{
	float d = discriminant(a,b,c);	
	
	if (d>0)
	{
		printf("Les racines sont : %f et %f\n",((-b-sqrt(d))/(2*a)),((-b+sqrt(d))/(2*a)));
	}
	else
	{
		if(d==0)
		{
			printf("La racine double est : %f\n",((float)-b/(2*a)));
		}
		else
		{
			printf("Pas de solutions\n");
		}
	}
}


int main()
{
	assert(discriminant(4,5,1)==9.0);
	assert(discriminant(1,0,0)==0.0);
	assert(discriminant(4,4,1)==0.0);
	assert(discriminant(5,6,2)==-4.0);
	printf("Pour le polynome 4*x^2 + 5*x + 1. ");
	afficheRacines(4,5,1);
	printf("Pour le polynome x^2. ");
	afficheRacines(1,0,0);
	printf("Pour le polynome 4*x^2+4*x+1. ");
	afficheRacines(4,4,0);
	printf("Pour le polynome 5*x^2+6*x+2. ");
	afficheRacines(5,6,2);
	
	return 0;
}

