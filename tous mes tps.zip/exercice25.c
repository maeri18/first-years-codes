#include<stdio.h>


void placeElt(float tab[],int i,int len)
{
	int j;
	int id=i;
	int temp;
	for(j=0;j<i;j++)
	{
		if (tab[j]>=tab[i])
		{
			id = j;
			break;
		}
	}
	 temp = tab[i];
	for(j = i;j>id;j--)
			{
				tab[j]=tab[j-1];
			}
			tab[id] = temp;
			
}
void affiche_tab(float tab[], int len)
{
	for(int i=0;i<len;i++)
	{printf("%f ",tab[i]);}
	
	printf("\n");
}


int main()
{
	float tab[5] = {5.0,2.0,3.0,6.0,1.0};
	placeElt(tab,4,5);
	affiche_tab(tab,5);
	float tab2[9]={1.0,5.0,2.1,4.2,8.6,6.3,2.2,1.2,5.6};
	placeElt(tab2,4,9);
	affiche_tab(tab2,9);
	return 0;
}
