#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include<assert.h>

#define NB_VALEURS 50
#define VMIN -20
#define VMAX 20

long long int valeur_aleatoire(int min, int max)
{
//NB plus besoin de faire un srand ici sinon on aura le meme nombre (execution trop rapide?)
long long int d ; //avec les int y avait depassement de capacite et j'avais que des nombres negatifs.
d= rand();
d=((max-min)*d)/RAND_MAX + min;
return d;

}

void pos_neg_zero(int* pos, int*neg,int * zer, long long int d)
{
 	if (d>0) *pos =*pos+1;
 	else if (d<0) *neg =*neg+1;
 	else *zer = *zer +1;
}
int main(){
  
  /* initialisation du g�n�rateur de nombres al�atoires */
  srand(time(NULL));
  int i;
  long long int d;
  int nb_pos=0,nb_neg=0,nb_zer=0;
  for(i=0;i<NB_VALEURS;i++)
  {
  d = valeur_aleatoire(VMIN,VMAX);
  assert((VMIN<=d)&&(d<=VMAX));
  pos_neg_zero(&nb_pos,&nb_neg,&nb_zer,d);
  printf("%lld ",d);
  }
  printf("nombres de positifs = %d nombres de negatifs = %d  nombres de zeros = %d\n",nb_pos,nb_neg,nb_zer);
  return 0;
}
