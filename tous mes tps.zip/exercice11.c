#include<stdio.h>
#include<assert.h>

// Question 1

int jours(int x, int pop, float p)
{ // précondition : pop >=0 && 0.0 >= p && p<=100.0 && x>=0
	int infect = 1;
	int i=0;
	float p1=0;
	while(p1<p)
	{
		
		infect = infect + infect * x;
		p1 = ((float)infect*100)/pop;
		i=i+1;
	}
	return i;
}

//Question 2

float pourcentage(int x, int pop, int jours)
{// préconditions : pop>=0 && x>=0 && jours>=0
	int i; 
	float infect = 1;
	float res;
	for(i=0; i<jours; i++)
	{
	infect = infect + infect * x;
	}
	res = ((infect * 100)/pop);
	return (res<=100.0)? res : 100.0;
}
int main()
{
	int x=5, pop = 10000;
	assert(jours(x,pop,100.0)==6);
	assert(jours(x,pop,50.0)==5);
	assert(jours(x,pop,25.0)==5);
	assert(jours(x,pop,10.0)==4);
	/*printf("%d\n",jours(x,pop,100.0));
	printf("%d\n",jours(x,pop,50.0));
	printf("%d\n",jours(x,pop,25.0));
	printf("%d\n",jours(x,pop,10.0));*/
	printf("%.2f\n",pourcentage(x,pop,2));
	printf("%.2f\n",pourcentage(x,pop,3));
	printf("%.2f\n",pourcentage(x,pop,4));
	printf("%.2f\n",pourcentage(x,pop,5));
	printf("%.2f\n",pourcentage(x,pop,6));
	return 0;
}

