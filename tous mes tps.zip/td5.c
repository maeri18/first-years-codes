#include <stdio.h>
#define NB_VILLES 5


int villes[NB_VILLES] = {29, 59, 67, 75, 83};
int distances[NB_VILLES] [NB_VILLES] = {
{0, 598, 900, 504, 995},
{598, 0, 407, 203, 861},
{900, 407, 0, 397, 621},
{504, 203, 397, 0, 694},
{995, 861, 621, 694, 0}
};

void affiche_distances(int villes[NB_VILLES] ,int dist[NB_VILLES] [NB_VILLES]){
	int i =0;
	int j =0;
	printf("km");
	for (i=0;i<NB_VILLES ; i++){
		printf("\t %d",villes[i]);
	}i=0;
	for(i=0;i<NB_VILLES ;i++){
		printf("\n %d" , villes[i]);
		for (j=0;j<NB_VILLES ;j++){
			if (dist[i][j]==0){
				printf("\t _");}
		
		
		else{printf("\t %d", dist[i][j]);}
		}}
	}
int plus_proche (int laville, int villes[], int dist[NB_VILLES][
NB_VILLES]){
int i =0;
int j =0;
int min =100000;
int indice=0;
int ville=0;
for (i=0;i<NB_VILLES;i++){

	if (villes[i]==laville){
		ville=i;}
		
}
	printf("indice :%d\n",ville);	
	for(j=0;j<NB_VILLES; j++){
	
		if((dist[ville][j]< min) && (dist[ville][j]!=0)){
			min =dist[ville][j];
			indice =j;}
	}

return indice;
}
			
			
		






int main() {
//affiche_distances(villes,distances//printf(" \n");
printf("l'indice de la ville la plus proche est %d \n ", plus_proche(29,villes,distances));
	return 0;}







