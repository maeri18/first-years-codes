// Exercice 37
#include<stdio.h>
#include<stdlib.h>
#include<time.h>
#include<cini.h>
#define HAUTEUR 22
#define LARGEUR 10
#define W_LARGEUR 1000
#define W_HAUTEUR HAUTEUR*(W_LARGEUR/LARGEUR)
#define VIDE -1
#define DIM 20


typedef struct une_case_{
int ligne;
int colonne;
}une_case;

typedef struct piece {
int pos_ligne,pos_colonne;
une_case la_piece[4];
int type;
}piece;

char* color[] = {"light salmon","fuchsia","lime green",
"white","yellow","cyan","grey"};
void remplir_case(int x, int y,char * color1)
{
	int dim = DIM;
	int i,j;
	x = x*dim;
	y = y*dim;
	for(i = x; i<x+dim;i++)
	{
		for(j=y;j<y+dim;j++)
		{
			CINI_draw_pixel(i,j, color1);
			
		}
	}	
	CINI_draw_line(x, y, x+dim, y, "black");
	CINI_draw_line(x, y, x, y+dim, "black");
	CINI_draw_line(x, y+dim, x+dim, y+dim, "black");
	CINI_draw_line(x+dim, y, x+dim, y+dim, "black");
		
}
void afficher_toutes_pieces(piece tab[7])
{
	
	int deplace = 0;
	
	int x, y;
	
	for(int i=0;i<7;i++)
	{

		
		for(int j=0;j<4;j++)
		{	
			x = tab[i].la_piece[j].ligne + deplace;
			y = tab[i].la_piece[j].colonne;
			remplir_case(x,y,color[tab[i].type]);	
		}
		deplace = deplace + 5;
	} 
	
	CINI_loop();
}

// Exercice 38
void init_plateau(int pla[HAUTEUR][LARGEUR])
{
	for(int i=0;i<HAUTEUR;i++)
	{
		for(int j=0;j<LARGEUR;j++)
		{
			pla[i][j]= VIDE;
		}
	}
}

void afficher_plateau(int pla[HAUTEUR][LARGEUR],char* couleur[])
{
	for(int i=0; i<LARGEUR;i++)
	{
		for(int j=0;j<HAUTEUR;j++)
		{
			if(pla[i][j]==VIDE)
			{
				remplir_case(i,j,"light pink");
			}
			else
			{
				remplir_case(i,j,color[pla[i][j]]);
			}
		}
	}
	
}
void re_init_window(int pla[HAUTEUR][LARGEUR])
{
	CINI_fill_window("light pink");
	afficher_plateau(pla, color);
}
int rand_piece()
{
	return rand()%7;
}
void init_piece(piece * p, piece tab[7])
{
	int typ_e = rand_piece();
	*p = tab[typ_e];
	p->pos_colonne = LARGEUR / 2;
}
void show_piece(piece p, piece tab[7])
{
	char * colour = color[p.type];
	for(int i =0; i<4;i++)
	{
		remplir_case(tab[p.type].la_piece[i].ligne + p.pos_colonne, tab[p.type].la_piece[i].colonne + p.pos_ligne ,colour);	
	}	
}
void update_piece(piece *p, int line, int col)
{
	if(line>=0 && line<=22)
	{
		p->pos_ligne = line;
	}
	if(col>=0 && col<=10)
	{
		p->pos_colonne = col;
	}	
}

//int descendre(int piece
int main()
{
	srand(time(NULL));
	CINI_open_window(W_LARGEUR,W_HAUTEUR, "Pieces");
	CINI_fill_window("light pink");
	piece tab_pieces[7]={{0,0,{{0,0},{1,0},{0,1},{1,1}},0}, {0,0,{{0,0},{0,1},{0,2},{0,3}},1} ,{0,0,{{0,0},{0,1},{0,2}, {1,2}},2}, {0,0,{{0,0}, {0,1} ,{0,2}, {-1,2}},3} , {0,0,{{0,0}, {1,0} ,{1,1}, {2,1}},4} , {0,0,{{0,0}, {1,0} ,{0,1}, {-1,1}},5} , {0,0,{{0,0}, {1,0} ,{2,0}, {1,1}},6}};
	int plateau[HAUTEUR][LARGEUR];
	init_plateau(plateau);
	afficher_plateau(plateau, color);
	//afficher_toutes_pieces(tab_pieces);
	//show_piece(tab_pieces[1], tab_pieces);
	//re_init_window();
	char move;
	piece curr ;
	init_piece(&curr, tab_pieces);
	show_piece(curr, tab_pieces);
	CINI_loop();
	scanf("%c",&move);
		
	while(move!=' ')
	{
		scanf("%c",&move);
		switch(move)
		{
			case 's':
			
				re_init_window(plateau);
				update_piece(&curr, curr.pos_ligne,curr.pos_colonne - 1);
				show_piece(curr, tab_pieces);
				CINI_loop();
				break;
			
			case 'd':
			
				re_init_window(plateau);
				update_piece(&curr, curr.pos_ligne +1,curr.pos_colonne);
				show_piece(curr, tab_pieces);
				CINI_loop();
				break;
			
			case 'f':
			
				re_init_window(plateau);
				update_piece(&curr, curr.pos_ligne ,curr.pos_colonne+ 1);
				show_piece(curr, tab_pieces);
				CINI_loop();
				break;
			
			
			case ' ':
			
				printf("FIN\n\n");
				break;
				
		}
		
	}
	
	CINI_loop();
	
	return 0;
}
