#include <stdio.h>
#include <stdlib.h>
#include <ctype.h>
#include <string.h>
#include <stdbool.h>
#include <math.h>
#define SEPARATOR "#<ab@17943918#@>#"

typedef struct _element_t element_t;
struct _element_t{
  int valeur;
  int frequence;
  element_t *suivant;
};

element_t * Recherche_val(element_t *ensemble, int val) 
{
	if(ensemble == NULL)
	{
		return NULL;
	}
	else if(ensemble->valeur == val)
	{
		return ensemble;
	}
	else
	{
		return Recherche_val(ensemble->suivant,val);
	}
}

/* Ajoute l'element val en tete de l'ensemble s'il n'apparait pas dans l'ensemble, augmente sa frequence de freq sinon */
element_t * Ajout_tete_ensemble(element_t *ensemble, int val, int freq) {
  element_t *ptr;
 
  ptr = Recherche_val(ensemble,val);
  if (ptr != NULL) {
    ptr->frequence = ptr->frequence+freq;
    return ensemble;
  } else {
    ptr=malloc(sizeof(element_t));
    ptr->valeur=val;
    ptr->frequence=freq;
    ptr->suivant=ensemble;
    return ptr;
  }
}

/* Affche tous les elements d'un ensemble avec leur frequence */
void Affiche_ensemble(element_t *ensemble) {
  element_t *ptr = ensemble;
  
  while (ptr != NULL) {
    printf("val : %d, frequence : %d\n",ptr->valeur,ptr->frequence);
    ptr=ptr->suivant;
  }
}

int Inclus_rec(element_t* e1, element_t* e2)
{
	if(e1 == NULL)
	{
		return 1;
	}
	
	if(e2 == NULL)
	{
		return 0;
	}
	
	if((e1->valeur == e2->valeur)&& (e2->frequence < e1->frequence))
	{
		return 0;
	}
	
	 if(e1->valeur == e2->valeur)
	{
		return Inclus_rec(e1->suivant, e2->suivant);
	}
	return Inclus_rec(e1, e2->suivant);
	
}


int main() 
   {
   	 
   /* creation d'un multi-ensemble trie contenant n1 valeurs differentes */
   element_t* multiE1 = NULL;
   element_t* multiE2 = NULL;
   printf("multiE1 : ");
   multiE1 = Ajout_tete_ensemble(multiE1,7,2);
   multiE1 = Ajout_tete_ensemble(multiE1,5,2);
   multiE1 = Ajout_tete_ensemble(multiE1,3,2);
   Affiche_ensemble(multiE1);
   /* creation d'un multi-ensemble trie contenant n2 valeurs differentes */
  
   printf("multiE2 : ");
   multiE2 = Ajout_tete_ensemble(multiE2,7,3);
   multiE2 = Ajout_tete_ensemble(multiE2,3,4);
   
   Affiche_ensemble(multiE2);
   printf("%d\n", Inclus_rec(multiE1, multiE2));
        return 0;
}
