#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#define PIERRE 1
#define FEUILLE PIERRE+1
#define CISEAUX FEUILLE+1
#define NBESSAIS 3
#define POINTSGAGNANTS 3 

  /* Il sera probablement n�cessaire de modifier les parametres et valeur de retour des fonctions */


//choix_joueur, score et jeu 

  /* Les declarations actuelles permettent de compiler et d'executer le programme */

void affichage_objet(int obj){
  /* hypoth�se : obj = PIERRE ou
     obj = FEUILLE ou obj = CISEAUX
   
   affiche le nom de l'objet correspondant � obj */
  
  if (obj == PIERRE){
    printf("PIERRE");
  } else {
    if (obj == FEUILLE){
      printf("FEUILLE");
    } else {
      printf("CISEAUX");
    }
  }
}

int choix_ordinateur()
{
 //srand(time(NULL));
 int d= rand();

 d = d%3+ PIERRE;
 return d;
} 

int choix_joueur() 
{
/* hypoth�ses : PIERRE < FEUILLE < CISEAUX 
  renvoie la valeur choisie par le joueur
  v�rifie qu'elle est comprise entre PIERRE et CISEAUX 
  redemande la saisie si ce n'est pas le cas
  
  Si apr�s NBESSAIS le joueur n'a pas saisi de valeur valable,
  cette derni�re est tir�e au sort */
  int i;
  int nb;
  for(i=0;i<NBESSAIS;i++)
  {
	  printf("Entrez un entier compris entre %d et %d\n",PIERRE,CISEAUX);
	  scanf("%d",&nb);
	  if (nb>=PIERRE && nb<=CISEAUX)
	  {
		  return nb;
	  }
  }
  return choix_ordinateur();
  
}

void score(int * sc_ordi, int * sc_jou, int ch_ordi, int ch_jou){
  /* hypoth�ses : le coup du joueur et celui de l'ordinateur sont valables 
                  (�gaux � PIERRE, FEUILLE ou CISEAUX)
   augmente de 1 le score du joueur si le coup du joueur est gagnant
   augmente de 1 le score de l'ordinateur si le coup de l'ordinateur est gagnant */
  if ((ch_ordi == PIERRE && ch_jou == CISEAUX)||(ch_ordi == CISEAUX  && ch_jou == FEUILLE)||(ch_ordi == FEUILLE  && ch_jou ==PIERRE))
  {
  *sc_ordi = *sc_ordi + 1;
  }
  else if ((ch_jou == PIERRE && ch_ordi == CISEAUX)||(ch_jou == CISEAUX  && ch_ordi == FEUILLE)||(ch_jou == FEUILLE  && ch_ordi ==PIERRE))
  {
  *sc_jou = *sc_jou + 1;
  }
  
}

void affect_str(char *str, char* aff)
{
int i=0;
while (aff[i]!='\0')
{
	str[i] = aff[i];
	i=i+1;
}

}
void jeu() {
  /* boucle de jeu, la partie s'arr�te d�s qu'un des deux joueurs 
   atteint POINTSGAGNANTS points */
   int sc_jou =0, sc_ordi =0, ch_jou, ch_ordi;
   char joueur[10];
   char ordi[10] ;
   printf("***********************************************************\n");
   while (sc_jou < POINTSGAGNANTS && sc_ordi <POINTSGAGNANTS)
   {
   ch_ordi= choix_ordinateur();
   ch_jou =choix_joueur();
   if (ch_jou == PIERRE){ affect_str(joueur,"Pierre");}
   else if (ch_jou == FEUILLE){affect_str(joueur,"Feuille");}
   else {affect_str(joueur,"Ciseaux");}
   
    if (ch_ordi == PIERRE){ affect_str(ordi, "Pierre");}
    else if (ch_ordi== FEUILLE){affect_str(ordi,"Feuille");}
    else {affect_str(ordi,"Ciseaux");}
 
   printf("***********************************************************\n\n");
   printf("|Choix de l'ordinateur : %7s|\n|Votre choix : %17s|\n", ordi,joueur);
   score(&sc_ordi, &sc_jou,ch_ordi,ch_jou);
   
printf("***********************************************************\n");
   printf("|Nouveaux scores:\n................\n|Ordinateur : %d\n|Vous: %d|\n",sc_ordi,sc_jou);
  printf("________________________________________________________________________\n");
   if (sc_ordi >sc_jou)
   {
   printf("\b|____Attention vous vous faites battre ! XD____|\n");
   }
   }
   if (sc_jou>sc_ordi)
   {printf("\n\n|************BRAVOOO VOUS AVEZ GAGNE***********|\n\n");}
   else 
   {printf("\n\n__________DEFAITE....CUISANTE..!__________\n\n|N'abandonnez pas. La vie est faite de hauts et de bas. On souffre tous un jour ou l'autre, mais le plus important c'est de se relever|\n\n");}
   printf("**************************************************************************\n\n");
   
  
}

int main() {
  
  srand(time(NULL));
 
 
 
 jeu();
  return 0;
}
